package JavaBoradData;

public class Product {

	String text = "";
	
	public Product (String aa){
		
		text = aa;
		
	}
	
	
	
}
