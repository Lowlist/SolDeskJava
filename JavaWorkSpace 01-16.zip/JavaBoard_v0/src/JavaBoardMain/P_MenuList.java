package JavaBoardMain;

import Util.Cw;

public class P_MenuList {
	
	static void menulistrun() {
		Cw.wn("글리스트");
	}
	

}
