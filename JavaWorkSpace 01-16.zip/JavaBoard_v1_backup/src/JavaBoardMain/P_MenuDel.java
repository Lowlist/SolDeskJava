package JavaBoardMain;

import java.util.Scanner;

import JavaBoradData.BoradFunsion;
import JavaBoradData.Product;
import Util.Cw;

public class P_MenuDel {

	
	
	public static void menudelrun() {
		int del_number = 0;
		int del_number2 = 0;
		boolean foundd = false;
		Scanner sc = new Scanner(System.in);
		Cw.wn("작성한 게시물을 삭제하는곳입니다.");
		start: 
			if(!BoradFunsion.listdata.isEmpty()) {
			P_MenuList.menulistrun();
			for (int i = 0; i < BoradFunsion.titledata.size(); i++) {
				Product del_list = BoradFunsion.listdata.get(i);
				del_number = i + 1;
				del_number2 = i + 1;
				// int 변수 +"" 하면 equals 문에서 문자열로 반환됨
				String cmd = sc.nextLine();
				if (cmd.equals(del_number + "")) {
					foundd = true;
					BoradFunsion.listdata.remove(del_number-1);
					BoradFunsion.titledata.remove(del_number2-1);
					Cw.wn("제목:"+del_list.title+" 글을 삭제하였습니다.");
				}
//				}else {
//					Cw.wn("〓〓〓〓〓〓〓〓〓〓〓〓〓");
//					System.out.println("올바른 명령어가 아닙니다!");
//					Cw.wn("〓〓〓〓〓〓〓〓〓〓〓〓〓");
//				}
					
				if (!foundd) {
					Cw.wn("〓〓〓〓〓〓〓〓〓〓〓〓〓");
					System.out.println("올바른 명령어가 아닙니다!");
					Cw.wn("〓〓〓〓〓〓〓〓〓〓〓〓〓");
				}

			}
			break start;
			
		}
	else {
	Cw.wn("저장된 글이 없습니다!");
		
}
}
}