//package com.lowlist.JavaBoardComment;
//
//import java.util.Map;
//import java.util.Scanner;
//
//import com.lowlist.JavaFunsionData.BoradFunsion;
//import com.lowlist.JavaFunsionData.Product;
//
//public class P_MenuIdComment {
//
//	public static void idcommentruns() {
//
//		System.out.println("게시판에 댓글을 다는곳 입니다!");
//		Scanner sc = new Scanner(System.in);
//		String cmd_select = sc.nextLine();
//		int select_borad = Integer.parseInt(cmd_select);
//		for(Map.Entry<Integer,Product> hashdataboard : BoradFunsion.BoradDataHash.entrySet()) {
//			if(select_borad == hashdataboard.get(select_borad-1)) {
//				if(hashdataboard.getValue(select_borad-1)) {
//					
//				}
//				
//			}
//		}
//		
//		
//		
//	}
//	
//	
//	
//}
