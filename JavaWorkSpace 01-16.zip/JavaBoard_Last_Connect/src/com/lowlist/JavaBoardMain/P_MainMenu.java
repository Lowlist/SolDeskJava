package com.lowlist.JavaBoardMain;

import com.lowlist.ApplyUtil.Ci;
import com.lowlist.ApplyUtil.Cw;
import com.lowlist.JavaBoardIdProcess.P_CreateId;
import com.lowlist.JavaBoardIdProcess.P_IdCheck;

public class P_MainMenu {
	
	public static void mainmenurun() {
//		Disp.menuMain();
		startid:
		while(true) {
			
			Cw.wn("id를 입력하시겠습니까? [1]예 [2]아니오 [3]ID만들기 [e]종료");
			String cmd_m =Ci.r("입력");
			switch(cmd_m) {
			case "1":
				P_IdCheck.idcheckrun();
				break;
			case "2":
				Cw.wn("비 로그인으로 진행하겠습니다.");
				P_MainMenuNonId.nonidrun();
				break;
			case "3":
				P_CreateId.createidrun();
				break;
			case "e":
				break startid;
			}
		
		}
	}
	
}
