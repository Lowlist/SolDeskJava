package com.lowlist.MySqlConnectJavaBorad;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.lowlist.ApplyUtil.Cw;
import com.lowlist.JavaFunsionData.BoradFunsion;
import com.lowlist.JavaFunsionData.Product;

public class MySqlConnect {
	public static Connection con = null;
	public static Statement st = null;
	public static ResultSet result = null;
	public static ResultSet result2 = null;
	public static ResultSet result3 = null;
	public static ResultSet result4 = null;

	public static void writerun(String xx) {
		dbExecuteUpdate(xx);
	}

	public static void createidrun(String xx) {
		dbExecuteUpdate(xx);
	}

	public static void readrun(String xx) {
		dbreadrun(xx);
	}

	public static void editrun(String xx) {
		dbeditrun(xx);
	}

	public static void javaaddrun() {
		dbjavaaddrun();
	}

	public static void listrun(String xx) {
		dblistrun(xx);
	}

	public static void viewrun(String xx) {
		dbview(xx);
	}

	public static void dbInit() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement(); // Statement는 정적 SQL문을 실행하고 결과를 반환받기 위한 객체다. Statement하나당 한개의 ResultSet 객체만을 열
										// 수있다.
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void dbExecuteUpdate(String query) {
		try {
			int resultCount = st.executeUpdate(query);
			System.out.println("데이터베이스에 업로드 된 글 갯수:" + resultCount);
			// 이거 굳이 필요없음
		} catch (SQLException e) {
			e.printStackTrace();
//			System.out.println("SQLException: " + e.getMessage());
//			System.out.println("SQLState: " + e.getSQLState());
		}
	}

	private static void dbview(String xx) {
		try {
			result = st.executeQuery(xx);
			result.next();
			String no = result.getString("b_no");
			String title = result.getString("b_title");
			String content = result.getString("b_text");
			String writer = result.getString("b_id");
			String b_hit = result.getString("b_hit");
			System.out.println(no + ".번");
			System.out.println("글제목: " + title);
			System.out.println("글내용: " + content);
			System.out.println("작성자: " + writer);
			System.out.println("조회수: " + b_hit);
			System.out.println("---------------------------");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void dbreadrun(String xx) {
		try {
			result = st.executeQuery(xx);
			result.next();
			String no = result.getString("b_no");
			String title = result.getString("b_title"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
			String content = result.getString("b_text");
			String writer = result.getString("b_id");
			String datetime = result.getString("b_datetime"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
			String b_hit = result.getString("b_hit"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
			System.out.println(no + "번 글을 불러옵니다.");
			System.out.println("글제목: " + title);
			System.out.println("글내용: " + content);
			System.out.println("작성자: " + writer);
			System.out.print("작성시간: " + datetime);
			System.out.println(" 조회수: " + b_hit);
			System.out.println("---------------------------");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static boolean dbchekuniqueno() {
		int uniqueno = 0;
			try {
				result = st.executeQuery("select * from board where b_unique_no");
				result.next();
				uniqueno = result.getInt("b_unique_no");
			} catch (SQLException e) {
				e.printStackTrace();
			}
			if (uniqueno == 0) {
				return false;
			}else {
				return true;
			}
	}

	public static void dblistrun(String xx) {
		try {
			String list = xx;
			result = st.executeQuery(list);

			while (result.next()) {

				String no = result.getString("b_no"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				String title = result.getString("b_title"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				String writer = result.getString("b_id"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				String datetime = result.getString("b_datetime"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				String b_hit = result.getString("b_hit"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				System.out.println(no + "번");
				System.out.println("글제목: " + title);
				System.out.println("작성자: " + writer);
				System.out.print("작성시간: " + datetime);
				System.out.println(" 조회수: " + b_hit);
				System.out.println("-----------------------------");

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void dbjavaaddrun() {
		try {

			String arraycon = "SELECT * FROM board";
			String arraycon2 = "SELECT * FROM board WHERE b_delnumber = 0";
			String arraycon3 = "SELECT * FROM board WHERE b_delnumber = 1";
			String idpw = "SELECT * FROM idpw";

			PreparedStatement ps = con.prepareStatement(arraycon);
			PreparedStatement ps_v = con.prepareStatement(arraycon2);
			PreparedStatement ps_d = con.prepareStatement(arraycon3);
			PreparedStatement ps_id = con.prepareStatement(idpw);

			result = ps.executeQuery();
			result2 = ps_v.executeQuery();
			result3 = ps_d.executeQuery();
			result4 = ps_id.executeQuery();

			while (result.next()) {
				int board_no = result.getInt("b_no");
				String board_title = result.getString("b_title");
				String board_text = result.getString("b_text");
				String board_write = result.getString("b_id");
				int board_del = result.getInt("b_delnumber");
				String board_postpw = result.getString("b_postpw");
				int board_unique_no = result.getInt("b_unique_no");
				BoradFunsion.countdata.add(new Product(board_no, board_title, board_text, board_write, board_del, board_postpw , board_unique_no));
			}
			while (result2.next()) {
				String board_title = result2.getString("b_title");
				String board_text = result2.getString("b_text");
				String board_write = result2.getString("b_id");
				String board_postpw = result2.getString("b_postpw");
				BoradFunsion.listdata.add(new Product(board_title, board_text, board_write, board_postpw));
			}
			while (result3.next()) {
				int board_no = result3.getInt("b_no");
				String board_title = result3.getString("b_title");
				String board_text = result3.getString("b_text");
				String board_write = result3.getString("b_id");
				int board_del = result3.getInt("b_delnumber");
				String board_postpw = result3.getString("b_postpw");
				int board_unique_no = result3.getInt("b_unique_no");
				BoradFunsion.delCount.add(new Product(board_no, board_title, board_text, board_write, board_del, board_postpw , board_unique_no));
			}
			while (result4.next()) {
				String board_id = result4.getString("b_id");
				String board_pw = result4.getString("b_pw");
				int unique_no = result4.getInt("b_no");
				BoradFunsion.idPwData.add(new Product(board_id, board_pw));
				BoradFunsion.iduniqueno.add(new Product(board_id, unique_no));
				BoradFunsion.idcount.add(board_id);
				BoradFunsion.PwData.add(board_pw);
			}

			for (int i = 0; i < BoradFunsion.countdata.size(); i++) {
				BoradFunsion.BoradDataHash.put(i, BoradFunsion.countdata.get(i));
			}
			for (int i = 0; i < BoradFunsion.idcount.size(); i++) {
				BoradFunsion.idPwDataHash.put(BoradFunsion.idcount.get(i), BoradFunsion.PwData.get(i));
			}
			for (int i = 0; i < BoradFunsion.idcount.size(); i++) {
				BoradFunsion.idPwUniqueNoHash.put(BoradFunsion.iduniqueno.get(i), BoradFunsion.PwData.get(i));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void dbeditrun(String xx) {
		try {
			int resultCount = st.executeUpdate(xx);
//			System.out.println("처리된 행 수:" + resultCount);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	static public int dbPostCount() {
		String count = "";
		try {
			result = st.executeQuery("select count(*) from board where b_delnumber=0");
			result.next();
			count = result.getString("count(*)");
//			Cw.wn("저장된 글 갯수:" + count);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		int intCount = Integer.parseInt(count);
		return intCount;
	}
	static public void dbPostCounttext() {
		String count = "";
		try {
			result = st.executeQuery("select count(*) from board where b_delnumber=0");
			result.next();
			count = result.getString("count(*)");
			Cw.wn("저장된 글 갯수:" + count);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	

}