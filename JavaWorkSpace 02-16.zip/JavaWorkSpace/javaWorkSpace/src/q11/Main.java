package q11;

public class Main {
	public static void main(String[] args) {
		
		Dice Dice = new Dice();
		
		Dice.x();
		
		int a = Dice.roll(3);
	}
	
}
