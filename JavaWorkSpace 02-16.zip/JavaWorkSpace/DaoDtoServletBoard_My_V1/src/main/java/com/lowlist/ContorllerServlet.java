package com.lowlist;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lowlist.BoardDao.BoardMemberDao;
import com.lowlist.Dto.Dto;
import com.lowlist.Dto.DtoMember;
import com.lowlist.service.serviceBoard;
@WebServlet("/board/*")
public class ContorllerServlet extends HttpServlet {
	String category;
	String nextPage;
	serviceBoard service;
	@Override
	public void init() throws ServletException {
		service = new serviceBoard();
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		String action = request.getPathInfo();
		
		if(action != null){
			switch(action) {
				case "/sign_up_page":
					nextPage = "/sign_up.jsp";
					break;
				case "/mainpage":
					nextPage = "/index.html";
					break;
				case "/write":
					nextPage = "/write.jsp";
					break;
				case "/del":
					nextPage = "/board/list";
					service.del(request.getParameter("no"));
					break;
				case "/edit":
					nextPage = "/edit.jsp";
					break;
				case "/write_proc":
					nextPage = "/board/list";
					Dto dto_write = new Dto(
							request.getParameter("title"),
							request.getParameter("id"),
							request.getParameter("content")
						);
					service.write(dto_write);
					break;
				case "/read":
					nextPage = "/read.jsp";
					break;
				case "/sign_up":
					nextPage = "/index.html";
					service.sign_up(request.getParameter("id"),request.getParameter("pw"));
					break;
				case "/login":
					if(service.login(request.getParameter("id"),request.getParameter("pw"))) {
						nextPage = "/board/list";
						 HttpSession session = request.getSession();
						 session.setAttribute("idkey", request.getParameter("id"));
						 session.setMaxInactiveInterval(360);
					}else {
						nextPage = "/index.html";
					}
					break;
				case "/edit_proc":
					nextPage = "/board/list";
					Dto dto_edit_proc = new Dto(
							request.getParameter("title"),
							request.getParameter("content")
							);
					service.edit(dto_edit_proc,request.getParameter("no"));
					break;
				case "/list":
					nextPage = "/list.jsp";
					break;
				}	
				
		System.out.println("현재페이지"+nextPage);
		
		RequestDispatcher d = request.getRequestDispatcher(nextPage);
		d.forward(request,response);
		}
		
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		
		DtoMember sign_up_load = new DtoMember(id,pw);
		BoardMemberDao sign_up_add = new BoardMemberDao();
		
		System.out.println("------------------");
		System.out.println(sign_up_load.id);
		System.out.println(sign_up_load.pw);
		
		if(id == null && pw == null || id.equals("null") && pw.equals("null")) {
			System.out.println("꺼져");
		}else {
			System.out.println("잘댐");
			sign_up_add.signup(sign_up_load);
		}
		
	}
	}
//		String id = request.getParameter("id");
//		String pw = request.getParameter("pw");
//		
//		BoardMemberDao login_add = new BoardMemberDao();
//		
//		if(login_add.login_run(id, pw)) {
//		    HttpSession session = request.getSession();
//		    session.setAttribute("idkey", id);
//		    session.setMaxInactiveInterval(360);
//		} else {
//		    System.out.println("id, pw 불일치");
//		}