package com.lowlist.BoardDao;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.lowlist.Dto.Dto;
import com.lowlist.MasterClass.Db;
import com.lowlist.MasterClass.MasterDao;
import com.lowlist.MasterClass.TotalPage_Block;

//인서트 = 쿼리 기타 다른것 = 업데이트 안하면 에러남
public class BoardListDao extends MasterDao {
	
	//수정
	public void edit(Dto d,String no) {
		try {
			String sql = String.format(
					"UPDATE %s SET b_title='%s',b_content='%s' WHERE b_no=%s"
					,Db.TABLE_PS_BOARD_FREE, d.title,d.content,no);
			super.update(sql);
			super.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//리스트
	public ArrayList<Dto> list(String page){
		ArrayList<Dto> posts = new ArrayList<>();
		try {
			int startIndex = ((Integer.parseInt(page))-1)*TotalPage_Block.LIST_AMOUNT;
			String sql = String.format(
					"SELECT * FROM %s WHERE b_del_number=0 limit %s,%s"
					,Db.TABLE_PS_BOARD_FREE,startIndex,TotalPage_Block.LIST_AMOUNT);
			ResultSet rs = super.Query(sql);
				while(rs.next()) {
					posts.add(new Dto(
						rs.getString("b_no"),
						rs.getString("b_title"),
						rs.getString("b_content"),
						rs.getString("b_id"),
						rs.getString("b_del_number"),
						rs.getString("b_hit"),
						rs.getString("b_datetime"),
						rs.getString("b_comment_count"),
						rs.getString("b_commnet_ori")
							));
						}
					super.close();
			} catch (Exception e) {
				e.printStackTrace();
			}	
		return posts;
	}
	
	//리스트 내에서 찾기
	public ArrayList<Dto> listsearch(String page,String word){
		ArrayList<Dto> posts = new ArrayList<>();
		try {
			int startIndex = ((Integer.parseInt(page))-1)*TotalPage_Block.LIST_AMOUNT;
			String sql = String.format(
					"SELECT * FROM %s WHERE b_del_number=0 and b_title like '%%%s%%' limit %s,%s"
					,Db.TABLE_PS_BOARD_FREE,word,startIndex,TotalPage_Block.LIST_AMOUNT);
			ResultSet rs = super.Query(sql);
				while(rs.next()) {
					posts.add(new Dto(
						rs.getString("b_no"),
						rs.getString("b_title"),
						rs.getString("b_content"),
						rs.getString("b_id"),
						rs.getString("b_del_number"),
						rs.getString("b_hit"),
						rs.getString("b_datetime"),
						rs.getString("b_comment_count"),
						rs.getString("b_commnet_ori")
							));
						}
					super.close();
			} catch (Exception e) {
				e.printStackTrace();
			}	
		return posts;
	}
	
	//읽기
	public Dto read(String no) {
		Dto post = null;
		try {
			String sql = String.format(
					"SELECT * FROM %s WHERE b_no=%s"
					,Db.TABLE_PS_BOARD_FREE,no);
			ResultSet rs = super.Query(sql);
				if(rs.next()==true) {
					post =new Dto(
						rs.getString("b_no"),
						rs.getString("b_title"),
						rs.getString("b_content"),
						rs.getString("b_id"),
						rs.getString("b_del_number"),
						rs.getString("b_hit"),
						rs.getString("b_datetime"),
						rs.getString("b_comment_count"),
						rs.getString("b_commnet_ori")
					);
				super.close();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return post;
	}
	//쓰기
	public void write(Dto d) {
		try {
			String sql = String.format(
					"INSERT INTO %s (b_title,b_id,b_content) VALUES ('%s','%s','%s')"
					,Db.TABLE_PS_BOARD_FREE, d.title,d.id,d.content);
				super.update(sql);
				super.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//삭제
	public void del(String no) {
		try {
			String sql = "UPDATE dog_board SET b_del_number = 1 WHERE b_no="+no;
			super.update(sql);
			super.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
