package JavaFunsionData;

public class MenuListData extends Product {

	public MenuListData(String aa ,int bb) {
		super(aa , bb);
	}

	
	
}
