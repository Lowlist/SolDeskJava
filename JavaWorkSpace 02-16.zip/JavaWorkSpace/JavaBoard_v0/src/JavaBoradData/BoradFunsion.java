package JavaBoradData;

import java.util.ArrayList;

public class BoradFunsion {
	
	public static ArrayList<Product> titledata = new ArrayList<Product>();
	public static ArrayList<Product> contentdata = new ArrayList<Product>();
	public static ArrayList<Product> writerdata = new ArrayList<Product>();
	
	




}
