package com.lowlist.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.lowlist.Db.Db;

public class Da {
	
	private Connection con = null;
	private PreparedStatement ps = null;
	
	void update(String xx) {
		try {
			connectMySQL();
			ps = con.prepareStatement(xx);
			ps.executeUpdate();
			System.out.println("전송한 sql:"+xx);
		}catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	ResultSet Query(String xx) {
		ResultSet rs = null;
		try {
			connectMySQL();
			ps = con.prepareStatement(xx);
			rs = ps.executeQuery();
			System.out.println("전송한 sql:"+xx);
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return rs;
	}
	
	void close() {
		try {
			if(ps != null) {
				ps.close();
			}
			if(con != null) {
				con.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void connectMySQL() throws ClassNotFoundException, SQLException {
		if(con == null || con.isClosed()) {
			Class.forName(Db.DB_JDBC_DRIVER_PACKAGE_PATH);
			con = DriverManager.getConnection(Db.DB_URL, Db.DB_ID, Db.DB_PW);
		}
	}
}
