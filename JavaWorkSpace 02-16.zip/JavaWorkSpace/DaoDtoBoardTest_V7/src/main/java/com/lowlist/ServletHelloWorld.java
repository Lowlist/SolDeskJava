package com.lowlist;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ServletHelloWorldssss")
public class ServletHelloWorld extends HttpServlet {
		@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		PrintWriter out = response.getWriter();
		out.println("hello world");
		String s = request.getParameter("id");
		String b = request.getParameter("pw");
		out.println(s);
		out.println(b);
		
		System.out.println("==== 두 겟");
		System.out.println("id: "+ request.getParameter("id"));
		System.out.println("pw: "+ request.getParameter("pw"));
		
		
		
	}

}
