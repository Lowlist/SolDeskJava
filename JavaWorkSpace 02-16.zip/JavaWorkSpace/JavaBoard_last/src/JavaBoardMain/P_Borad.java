package JavaBoardMain;

import Display.Disp;

public class P_Borad {

	void boradrun(){
		
		Disp.title();
		P_MainMenu.mainmenurun();
		
	}
	
}
