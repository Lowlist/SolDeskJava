package MySqlConnect;

public class IdConnect {

}
