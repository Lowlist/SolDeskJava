let divId;
let changeHover;
let starForceData;
let change;
let datas;
let equip_level;
$(document).ready(
    function () {
        let item_info = $('.item_popup_main');
        let hoverring = $('.item');
        let starforceline = $('.star_force_line');
        //아이템 div부분에 마우스를 가져다가 댔을때 발동
        hoverring.hover(function () {
            divId = $(this).attr('id');
            starForceData = $(this).data(divId);
            equip_level = $(this).data('equip_level');
            starforcerun();
            item_info.show();
            starforceline.show();
        }, function () {
            item_info.hide();
            starforceline.hide();
        });
    });
function starforcerun() {
    let maxstarforce;
    let starforce = parseInt(starForceData);
    let starimg = "https://cdn.dak.gg/maple/images/tooltip/item/ico-starforce-yellow.png";
    let starblackimg = "https://cdn.dak.gg/maple/images/tooltip/item/ico-starforce-default.png";
    let container = document.getElementById("starforce");
    container.innerHTML = '';
    let equip_level_check= parseInt(equip_level);
    if(equip_level_check <= 94){
        maxstarforce = 5;
    } else if (equip_level_check <=107){
        maxstarforce = 7;
    } else if (equip_level_check <=117){
        maxstarforce = 10;
    } else if (equip_level_check <=127){
        maxstarforce = 15;
    } else if (equip_level_check <=137){
        maxstarforce = 20;
    } else if (equip_level_check >=138){
        maxstarforce = 25;
    }
    // 별 이미지 추가
    if (starforce != 0) {
        
        for (let i = 1; i <= starforce; i++) {
            let image = document.createElement("img");
            image.src = starimg;
            image.alt = "별 이미지";
            image.className = "starforceimg";
            container.appendChild(image);
            if (i % 5 === 0) {
                container.appendChild(document.createTextNode(" "));
            }
        }

        // 부족한 별 이미지 추가
        if (starforce <= maxstarforce) {
            for (let i = starforce + 1; i <= maxstarforce; i++) {
                let image = document.createElement("img");
                image.src = starblackimg;
                image.alt = "별 이미지";
                image.className = "starforceimg";
                container.appendChild(image);
                if (i % 5 === 0) {
                    container.appendChild(document.createTextNode(" "));
                }
            }
        }
    }
};
