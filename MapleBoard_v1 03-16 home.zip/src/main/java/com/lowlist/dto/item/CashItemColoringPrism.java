package com.lowlist.dto.item;

import lombok.Data;

@Data
public class CashItemColoringPrism{
    public String color_range;
    public int hue;
    public int saturation;
    public int value;
}