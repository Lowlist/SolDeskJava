package JavaBoardMain;

public class Main {
	
	public static void main(String[] args) {
		
		P_Borad borad = new P_Borad();
		
		borad.boradrun();
		
	}
}
