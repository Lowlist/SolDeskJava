package MenuInfo;

public class DrinkData extends Product {
	
	public DrinkData(String xx, int yy, String aa) {
		super(xx, yy, aa);
	}
	

}
