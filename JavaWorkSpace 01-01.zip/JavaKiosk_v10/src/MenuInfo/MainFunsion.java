package MenuInfo;

import java.util.ArrayList;
import java.util.Scanner;

public class MainFunsion{
	
	// 배열 추가는 public static void 쓰는 main 에서만 가능
	public static ArrayList<Product> drink = new ArrayList<Product>();
	public static ArrayList<Product> drinksize = new ArrayList<Product>();
	public static ArrayList<Product> dessert= new ArrayList<Product>();
	public static ArrayList<Product> drink_T = new ArrayList<Product>();
	public static ArrayList<Product> dessert_T= new ArrayList<Product>();
	public static ArrayList<Product> LastOrder= new ArrayList<Product>();
	
	public static Scanner sc = new Scanner(System.in);
	public static String cmd;
	
	public static void drinkload() {
	//음료수
	drink.add(new DrinkData("뜨거운커피",2000,"1"));
	drink.add(new DrinkData("아이스아메리카노",2500,"2"));
	drink.add(new DrinkData("딸기스무디",4000,"3"));
	drink.add(new DrinkData("복숭아스무디",4000,"4"));
	}
	
	public static void dessertload() {
	//디저트
	dessert.add(new DessertData("케이크",5000,"1"));
	dessert.add(new DessertData("마카롱",3000,"2"));
	dessert.add(new DessertData("샌드위치",4000,"3"));
	}
	
	public static void drinksizeload() {
	//사이즈 업
	drinksize.add(new DrinkSizeData("톨(기본)",0,"1"));
	drinksize.add(new DrinkSizeData("그란데",2000,"2"));
	drinksize.add(new DrinkSizeData("벤티",4000,"3"));
	drinksize.add(new DrinkSizeData("트렌타",6000,"4"));
	}
	
}