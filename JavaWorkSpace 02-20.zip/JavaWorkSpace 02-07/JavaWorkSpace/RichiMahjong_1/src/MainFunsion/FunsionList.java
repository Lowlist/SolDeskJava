package MainFunsion;

import java.util.ArrayList;
import java.util.HashMap;

public class FunsionList {

	public static ArrayList<Product> hainumber = new ArrayList<Product>();

	public static ArrayList<Product> hainame = new ArrayList<Product>();

	public static HashMap<ArrayList<Product>,ArrayList<Product>> haipaicalc = new HashMap<>();
	
}
