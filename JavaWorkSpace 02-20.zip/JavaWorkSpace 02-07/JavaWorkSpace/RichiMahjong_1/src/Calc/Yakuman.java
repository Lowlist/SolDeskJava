package Calc;

public class Yakuman {

	void yakumanrun() {
		
		
		
		
		
		
	}
	
	
}
