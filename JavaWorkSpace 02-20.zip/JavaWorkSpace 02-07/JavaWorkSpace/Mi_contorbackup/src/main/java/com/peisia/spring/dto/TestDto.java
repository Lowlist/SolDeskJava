package com.peisia.spring.dto;

import lombok.Data;

@Data
public class TestDto {
	private Long no;
	private int nooo;
	private String str_data;
	private int ab;
	private String cd;
	//롬복 라이브러리가 아래 게터함수, 세터함수를 자동으로 만들어줌. @Data 라고 붙이면.
	
	//게터, 게터함수, 게터메소드
//	public Long getNo() {
//		return no;
//	}
	
	//세터
//	public void setNo(Long no) {
//		this.no = no;
//	}
	
	//str_data 쪽 게터,세터도 ...
	
	public TestDto(int nooo, String str_data) {
		this.nooo = nooo;
		this.str_data = str_data;
	}

	public TestDto(int nooo, String str_data, int ab, String cd) {
		this.nooo = nooo;
		this.str_data = str_data;
		this.ab = ab;
		this.cd = cd;
	};
}