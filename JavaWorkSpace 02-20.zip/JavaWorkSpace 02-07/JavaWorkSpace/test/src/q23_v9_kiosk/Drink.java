package q23_v9_kiosk;

public class Drink extends MenuInfo {

	//아래 함수를 선언하고 다른곳으로 불러오려면 java 파일명.n; 으로 선언하면 불러올수있음
	public static void drinkinfo(){
		System.out.println("-------드링크 메뉴입니다-------");
			dr1.info();
			dr2.info();
			dr3.info();
			dr4.info();
		System.out.println("이전 메뉴 [e] / 메뉴 다시보기 [r]");	
		System.out.println("---------------------------");
		drinkstrat:
		while(true) {
				System.out.println("드링크를 선택해주세요!");
				System.out.println("이전메뉴 [e] 메뉴 다시보기 [r]");
				System.out.println("장바구니 비우기[c] 장바구니 확인[v]");
				cmd = sc.next();
			switch(cmd) {
				case "1":
					dr1.addsetdrink();
					drink.add(dr1);
					DrinkSize.drinksize();
					break;
				case "2":
					dr2.addsetdrink();
					drink.add(dr2);
					DrinkSize.drinksize();
					break;
				case "3":
					dr3.addsetdrink();
					drink.add(dr3);
					DrinkSize.drinksize();
					break;
				case "4":
					dr4.addsetdrink();
					drink.add(dr4);
					DrinkSize.drinksize();
					break;
				case "r":
					System.out.println("-------드링크 메뉴입니다-------");
					dr1.info();
					dr2.info();
					dr3.info();
					dr4.info();
					System.out.println("이전 메뉴 e / 메뉴 다시보기 r");	
					System.out.println("---------------------------");
					break;
				case "e":
					break drinkstrat;
				case "c":
					drink.clear();
					drinksize.clear();
					dessert.clear();
					break;
				case "v":
					String sum_s1;
					String sum_s2;
					String sum_s3;
					int sum_i1;
					int sum_i2;
					int sum_i3;
					for(Product a : drink) {
						sum_s1 = a.name;
						sum_i1 = a.price;
						System.out.print(sum_s1 +"[" + sum_i1 +"],");
					}
						for(Product b : drinksize) {
							sum_s2 = b.name;
							sum_i2 = b.price;
							System.out.print(sum_s2 +"[" + sum_i2 +"],");
						}
							for(Product c : dessert) {  
								sum_s3 = c.name;
								sum_i3 = c.price;
								System.out.print(sum_s3 +"[" + sum_i3 +"],");
							}
					} //케이스 v
			
				}
			}
		}
	
