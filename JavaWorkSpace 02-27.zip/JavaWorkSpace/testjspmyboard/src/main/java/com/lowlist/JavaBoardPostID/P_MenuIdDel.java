package com.lowlist.JavaBoardPostID;

import java.util.Scanner;

import com.lowlist.ApplyUtil.Cw;
import com.lowlist.Dao.MySqlConnect;
import com.lowlist.Dao.P_BoradClear;
import com.lowlist.JavaBoardIdProcess.P_IdCheck;
import com.lowlist.JavaBoardListRead.P_MenuList;
import com.lowlist.JavaFunsionData.BoradFunsion;
import com.lowlist.JavaFunsionData.Product;

public class P_MenuIdDel {

	public static String nonidpostreal;
	public static void menudelrun() {

		Scanner sc = new Scanner(System.in);
		Cw.wn("작성한 게시물을 삭제하는 곳입니다.");
		boolean del_nonidchek = false;
		boolean del_idchek = false;
		String nonidpost;
		if (!BoradFunsion.listdata.isEmpty()) {
			P_MenuList.menulistrun("[번호입력]페이지넘기기 [삭제메뉴:x]");
			Cw.wn("삭제할 게시물 번호를 입력하세요[번호이외:뒤로가기]");
//			CalcHashMap.calcrun();
			String input = sc.nextLine();

			// gpt 님의 코드입니다.

			try {
				int del_numbers = Integer.parseInt(input); // 문자열을 숫자로 변환
					if (del_numbers > 0 && del_numbers <= BoradFunsion.countdata.size()) {
						
						for(int i = 0;i<BoradFunsion.countdata.size();i++) {
							Product unique_number = BoradFunsion.BoradDataHash.get(i);
							if(BoradFunsion.BoradDataHash.get(del_numbers-1).del_number==1) {
								Cw.wn("게시물이 존재하지 않습니다!");
								break;
							}
							if(BoradFunsion.BoradDataHash.get(i).del_number == 0 && BoradFunsion.BoradDataHash.get(del_numbers-1).b_unique_no ==0) {
								System.out.println("게시물 비밀번호를 입력해주세요!");
								nonidpost = sc.nextLine();
								nonidpostreal=nonidpost;
								if(nonidpostreal.equals(BoradFunsion.BoradDataHash.get(del_numbers-1).post_pw)) {
								String dbdel = "UPDATE board Set b_delnumber = 1 Where b_no="+del_numbers;
								MySqlConnect.writerun(dbdel);
								
								P_BoradClear.clearborad();
								MySqlConnect.javaaddrun();
								del_nonidchek = true;
								break;
								}else {System.out.println("삭제실패");}
								break;
							}
							if(BoradFunsion.BoradDataHash.get(i).del_number==0 
								&& P_IdCheck.Unique_number == unique_number.b_unique_no
								&& BoradFunsion.BoradDataHash.get(i).b_unique_no !=0 ) {
								String dbdel = "UPDATE board Set b_delnumber = 1 Where b_no="+del_numbers+" and b_unique_no like '%"+P_IdCheck.Unique_number+"%'";
								MySqlConnect.writerun(dbdel);
								
								P_BoradClear.clearborad();
								MySqlConnect.javaaddrun();
								
								String delview ="SELECT *from board WHERE b_no="+del_numbers;
								MySqlConnect.viewrun(delview);
								del_idchek = true;
								
								break;
								} 
							
							}
						}else{
						//두번째 if문 else 란 (입력한 번호가 게시물 범위 내에 있는지 확인)
						Cw.wn("게시글 넘버를 제대로 입력해주세요!");
					}
					//try catch 문으로 숫자열 이외의 값을 받을경우 출력
				}catch (NumberFormatException e) {
				Cw.wn("뒤로 돌아갑니다.");
			}
			
			if(!del_idchek && del_nonidchek) {
				System.out.println("비로그인꺼 삭제함");
			}
			if(!del_nonidchek && del_idchek) {
				System.out.println("아이디꺼 삭제함");
			}
			
		}else{
			//맨 처음 if문 else란 (저장된 글 확인)
			Cw.wn("저장된 글이 없습니다!");
		}

	}
}
