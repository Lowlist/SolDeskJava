package com.lowlist.Dao;

import com.lowlist.JavaFunsionData.BoradFunsion;

public class P_BoradClear {

	public static void clearborad() {
		BoradFunsion.countdata.clear();
		BoradFunsion.listdata.clear();
		BoradFunsion.delCount.clear();
		BoradFunsion.BoradDataHash.clear();
	}
	public static void clearidpw() {
		BoradFunsion.idcount.clear();
		BoradFunsion.idPwData.clear();
		BoradFunsion.PwData.clear();
		BoradFunsion.idPwDataHash.clear();
		BoradFunsion.idPwUniqueNoHash.clear();
		BoradFunsion.iduniqueno.clear();
		
	}
	
}
