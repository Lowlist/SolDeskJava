package com.lowlist.JavaBoardPostID;

import java.util.Scanner;

import com.lowlist.ApplyUtil.Cw;
import com.lowlist.Dao.MySqlConnect;
import com.lowlist.JavaBoardIdProcess.P_IdCheck;

public class P_MenuIdComment {
	
	public static void menuidcommentrun(int xx) {
		
		Scanner sc = new Scanner(System.in);
		String comment_add;
		while (true) {
			System.out.println("작성할 댓글을 입력해주세요!:");
			comment_add = sc.nextLine();
			if (comment_add.length() > 0) {
				break;
			} else {
				Cw.wn("1개 이상의 문자를 입력해주세요!");
			}
		}
	
		String dbcomment = String.format(
				"insert into commentall (b_connect_comment,b_comment,b_comment_id,b_comment_writer) "
						+ "values ('%d','%s','%s','%s');"
						,xx,comment_add,P_IdCheck.Unique_number,P_IdCheck.idwiter);
		MySqlConnect.editrun(dbcomment);
		
	}
	
}
