package com.lowlist.dto.item;

import lombok.Data;

@Data
public class Title {
	public String title_name;
	public String title_icon;
	public String title_description;
	public Object date_expire;
	public Object date_option_expire;

}
