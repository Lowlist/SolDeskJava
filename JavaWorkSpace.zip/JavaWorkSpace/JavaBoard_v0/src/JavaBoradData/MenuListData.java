package JavaBoradData;

public class MenuListData extends Product {

	public MenuListData(String aa) {
		super(aa);
	}

}
