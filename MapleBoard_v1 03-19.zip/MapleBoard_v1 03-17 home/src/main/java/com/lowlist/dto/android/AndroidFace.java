package com.lowlist.dto.android;

import lombok.Data;

@Data
public class AndroidFace {
	public String face_name;
	public String base_color;
	public Object mix_color;
	public String mix_rate;
}