package com.lowlist.JavaBoradAdmin;

import java.util.Map;
import java.util.Scanner;

import com.lowlist.ApplyUtil.Ci;
import com.lowlist.ApplyUtil.Cw;
import com.lowlist.JavaFunsionData.BoradFunsion;
import com.lowlist.JavaFunsionData.Product;
import com.lowlist.MySqlConnectJavaBorad.MySqlConnect;

public class P_MenuAdminEditPost {

	// 글 수정하는곳
	static void menueditpostrun() {
		
		Scanner sc = new Scanner(System.in);
		if (!BoradFunsion.listdata.isEmpty()) {
			int edit_number;
			editstart: 
				while (true) {
				MySqlConnect.listrun("SELECT * FROM board WHERE b_delnumber = 0");
				String cmd = Ci.r("수정할글번호 입력 [b]뒤로가기");
				boolean foundd = false;
				switch (cmd) {
				case "b":
					break editstart;
				}
				for (Map.Entry<Integer, Product> edit_list : BoradFunsion.BoradDataHash.entrySet()) {
					// 해쉬맵은 신이다.
					edit_number = Integer.parseInt(cmd);
					if (edit_list.getValue().del_number == 0 && edit_list.getValue().b_no == edit_number) {
						if (cmd.equals(edit_number + "")) {
							foundd = true;
							Cw.wn("원문제목:");
							Cw.wn(edit_list.getValue().title);
							Cw.wn("----------------------");
							Cw.wn("수정할 제목을 입력해주세요!");

							String title = sc.nextLine();
							edit_list.getValue().title = title;

							MySqlConnect.editrun(
									"update board set b_title='" + title + "' where b_no='" + edit_number + "' ");

							Cw.wn("수정한제목:");
							Cw.wn(edit_list.getValue().title);
							Cw.wn("---------수정완료---------");
						}
						if (cmd.equals(edit_number + "")) {
							foundd = true;
							Cw.wn("원문내용:");
							Cw.wn(edit_list.getValue().content);
							Cw.wn("----------------------");
							Cw.wn("수정할 내용을 입력해주세요!");

							String content = sc.nextLine();
							edit_list.getValue().content = content;
							MySqlConnect.editrun(
									"update board set b_text='" + content + "' where b_no='" + edit_number + "' ");

							Cw.wn("수정한내용:");
							Cw.wn(edit_list.getValue().content);
							Cw.wn("---------수정완료---------");
						}
						if (edit_list.getValue().b_unique_no == 0) {
							if (cmd.equals(edit_number + "")) {
								foundd = true;
								Cw.wn("원문내용:");
								Cw.wn(edit_list.getValue().write);
								Cw.wn("----------------------");
								Cw.wn("수정할 작성자를 입력해주세요!");

								String write = sc.nextLine();
								edit_list.getValue().write = write;
								MySqlConnect.editrun(
										"update board set b_id='" + write + "' where b_no='" + edit_number + "' ");

								Cw.wn("수정한내용:");
								Cw.wn(edit_list.getValue().write);
								Cw.wn("---------수정완료---------");
							}

						} else {
							Cw.wn("---------수정완료---------");
						}
						if (!foundd) {
							Cw.wn("〓〓〓〓〓〓〓〓〓〓〓〓〓");
							System.out.println("올바른 명령어가 아닙니다!");
							Cw.wn("〓〓〓〓〓〓〓〓〓〓〓〓〓");
							break;
						}
					}
				}
			}

		} else {
			Cw.wn("저장된 글이 없습니다!");
		}

	}

}
