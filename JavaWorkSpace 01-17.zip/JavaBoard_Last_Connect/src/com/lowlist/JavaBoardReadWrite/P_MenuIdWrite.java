package com.lowlist.JavaBoardReadWrite;

import com.lowlist.ApplyUtil.Ci;
import com.lowlist.ApplyUtil.Cw;
import com.lowlist.JavaBoardIdProcess.P_IdCheck;
import com.lowlist.MySqlConnectJavaBorad.MySqlConnect;
import com.lowlist.MySqlConnectJavaBorad.P_BoradClear;

public class P_MenuIdWrite {
	public static void menuidwriterun() {
		//제목
		String title ="";
			while (true) {
				title = Ci.rw("글제목");
				if (title.length() > 0) {
//					BoradFunsion.countdata.add(new Product(title));
					break;
				} else {
					Cw.wn("1개 이상의 문자를 입력해주세요!");
				}
			}
		//내용
		String content;
			while (true) {
				content = Ci.rw("글내용");
				if (content.length() > 0) {
					break;
				} else {
					Cw.wn("1개 이상의 문자를 입력해주세요!");
				}
			}
		//작성자
		String Id_writer;
				Id_writer = P_IdCheck.idwiter;
//			Product list_all = new Product(title,content,Id_writer);
//			BoradFunsion.listdata.add(list_all);
		//글 고유번호
		int unique_no;
				unique_no =P_IdCheck.Unique_number;
			Cw.wn("작성완료");
			
			String dbwriter = String.format(
					"insert into board (b_title,b_id,b_datetime,b_text,b_hit,b_unique_no) "
					+ "values ('%s','%s',now(),'%s',0,'%d');"
					,title,Id_writer,content,unique_no);
			
			MySqlConnect.writerun(dbwriter);
			P_BoradClear.clearborad();
			MySqlConnect.javaaddrun();
			}
		}

