package com.lowlist.JavaBoardComment;

import java.util.Scanner;

import com.lowlist.JavaBoardIdProcess.P_IdCheck;
import com.lowlist.JavaFunsionData.BoradFunsion;
import com.lowlist.MySqlConnectJavaBorad.MySqlConnect;
import com.lowlist.MySqlConnectJavaBorad.P_BoradClear;

public class CommentCheck {

	public static void idcommentruns() {
		
		Scanner sc = new Scanner(System.in);
		if (!BoradFunsion.listdata.isEmpty()) {
			boolean commentchek = false;
			System.out.println("게시판에 댓글을 다는곳 입니다!");
			System.out.println("댓글을 입력할 게시물 번호를 입력해주세요!");
			String cmd_select = sc.nextLine();

			try {
				int select_borad = Integer.parseInt(cmd_select);

				if (select_borad > 0 && select_borad <= BoradFunsion.countdata.size()) {

					for (int i = 0; i < BoradFunsion.countdata.size(); i++) {
						if (BoradFunsion.BoradDataHash.get(select_borad - 1).del_number == 1) {
							if (!commentchek) {
								System.out.println("게시물이 존재하지 않습니다!");
								break;
							} else {
								System.out.println("댓글작성완료!");
								break;
							}
						}
						
						if (BoradFunsion.BoradDataHash.get(i).del_number == 0) {
							//아이디 입력했을때 출력
							if(P_IdCheck.Unique_number != 0) {
								// 재원이형이 알려줬는데 set 여러개 하려면 컴마넣으면 됨 
								
								P_MenuIdComment.menuidcommentrun(select_borad);
								String commentcount = "UPDATE board SET b_comment = b_comment+1 WHERE b_no=" + cmd_select;
								MySqlConnect.editrun(commentcount);
								
								P_BoradClear.clearborad();
								MySqlConnect.javaaddrun();
								System.out.println("댓글작성완료!");
								commentchek = true;
								break;
							}
							//아이디 없을때 출력
							if(P_IdCheck.Unique_number == 0) {
								
								P_MenuNonIdComment.menunonidcommentrun(select_borad);
								String commentcount = "UPDATE board SET b_comment = b_comment+1 WHERE b_no=" + cmd_select;
								MySqlConnect.editrun(commentcount);
								
								P_BoradClear.clearborad();
								MySqlConnect.javaaddrun();

								System.out.println("댓글작성완료!");
								commentchek = true;
								break;
							}
							break;
						}
				}
			}else {
				System.out.println("유효한 게시물 범위가 아닙니다!");
			}
				
			} catch (NumberFormatException e) {
				System.out.println("유효한 입력이 아닙니다.");
			}
		}

	}
}