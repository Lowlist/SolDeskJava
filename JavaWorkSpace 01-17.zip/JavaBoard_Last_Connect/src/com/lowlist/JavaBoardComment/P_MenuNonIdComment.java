package com.lowlist.JavaBoardComment;

import java.util.Scanner;

import com.lowlist.ApplyUtil.Cw;
import com.lowlist.JavaBoardIdProcess.P_IdCheck;
import com.lowlist.MySqlConnectJavaBorad.MySqlConnect;

public class P_MenuNonIdComment {
	
	public static void menunonidcommentrun(int xx) {
		Scanner sc = new Scanner(System.in);
		String comment_add;
		String comment_nonidpw;
		String comment_nonidwriter;
		while (true) {
			System.out.println("작성할 댓글을 입력해주세요!:");
			comment_add = sc.nextLine();
			if (comment_add.length() > 0) {
				break;
			} else {
				Cw.wn("1개 이상의 문자를 입력해주세요!");
			}
		}
		
		while (true) {
			System.out.println("댓글작성자를 입력해주세요!:");
			comment_nonidwriter = sc.nextLine();
			if (comment_nonidwriter.length() > 0) {
				break;
			} else {
				Cw.wn("1개 이상의 문자를 입력해주세요!");
			}
		}
		
		while (true) {
			System.out.println("댓글비밀번호를 입력해주세요!:");
			comment_nonidpw = sc.nextLine();
			if (comment_nonidpw.length() > 0) {
				break;
			} else {
				Cw.wn("1개 이상의 문자를 입력해주세요!");
			}
		}
		String dbcomment = String.format(
				"insert into commentall (b_connect_comment,b_comment,b_comment_id,b_comment_nonidpw,b_comment_writer) "
						+ "values ('%d','%s','%s','%s','%s');"
						,xx,comment_add,P_IdCheck.Unique_number,comment_nonidpw,comment_nonidwriter+"[비로그인]");
		MySqlConnect.editrun(dbcomment);
	}
	
}
