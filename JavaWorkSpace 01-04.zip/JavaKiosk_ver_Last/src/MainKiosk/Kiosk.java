package MainKiosk;

import CheckAndCash.LastCash;
import CheckAndCash.MenuCheck;
import MenuInfo.MainFunsion;
import Util.Cw;

public class Kiosk{
	//메인 키오스크 정보 출력란
	void run() {
		MainFunsion.drinkload();
		MainFunsion.drinksizeload();
		MainFunsion.dessertload();
		Cw.wn("디저트 카페 ABC에 오신걸 환영합니다!!!");
		start:
			while(true) {
				Cw.wn("-------선택해주세요--------");
				Cw.wn("[1.드링크][2.디저트][3.장바구니확인]");
				Cw.wn("[4.장바구니비우기][x.계산 및 프로그램종료]");
				MainFunsion.cmd = MainFunsion.sc.next();
				switch(MainFunsion.cmd) {
				case "1":
					Drink.drinkinfo();
					break;
				case "2":
					Dessert.dessertinfo();
					break;
				case "3":
					MenuCheck.drinkcheckrun();
					MenuCheck.dessertcheckrun();
					break;
				case "4":
					MainFunsion.drink_T.clear();
					MainFunsion.dessert_T.clear();
					break;
				case "x":
					MenuCheck.drinkcheckrun();
					MenuCheck.dessertcheckrun();
					LastCash.Lastcashrun();
					break start;
				}
			}

	}
	
}
