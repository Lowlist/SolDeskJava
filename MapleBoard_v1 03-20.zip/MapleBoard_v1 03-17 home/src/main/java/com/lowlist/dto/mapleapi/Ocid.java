package com.lowlist.dto.mapleapi;

import lombok.Data;

@Data
public class Ocid {
	
	private String ocid;
	private String character_name;
	
}
