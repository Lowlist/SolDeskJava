package JavaBoardMain;

import MySqlConnect.MySqlConnect;

public class Main {
	public static void main(String[] args) {
		P_Borad borad = new P_Borad();

		MySqlConnect.dbInit();
		MySqlConnect.javaaddrun();
		borad.boradrun();
		
	}

}

/*
 * 1.글 리스트에서 글 볼수있게 바꾸기 (글 리스트가 없으면 저장된 글이 없습니다 출력) 
 * 2.글수정에서 글 리스트만 출력 된 다음에 선택 후 바꿀수 있게 하기 
 * 3.페이지 변경 기준 아마 6~8개정도? 
 * 4.글 삭제 구현 글 내용은 표시 안해도 됨. 
 * 5.삭제된 글을 저장하는 새로운 배열을 만든다음에 복구 누르면 복구되도록 만들기.
 * 6.코드 이쁘게 정리
 */
