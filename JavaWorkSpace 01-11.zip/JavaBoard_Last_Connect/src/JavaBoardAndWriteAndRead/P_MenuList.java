//package JavaBoardAndWriteAndRead;
//
//import java.sql.SQLException;
//import java.time.LocalDate;
//import JavaFunsionData.BoradFunsion;
//import JavaFunsionData.DataForBorad;
//import JavaFunsionData.Product;
//import Util.Cw;
//
//public class P_MenuList {
//	static public final int PER_PAGE = 3;
//	static public void menulistrun() {
//		int startIndex = 0;		// 현재 페이지의 첫 글 인덱스
//		int currentPage = 1;	// 현재 페이지
//		
//		////	전체 페이지 수를 구하기	////
//		int totalPage = 0;
//		if(Db.getPostCount() % PER_PAGE > 0) {
//			totalPage = Db.getPostCount() / PER_PAGE + 1;
//		}else {
//			totalPage = Db.getPostCount() / PER_PAGE;
//		}
//		
//		Cw.wn("총 페이지 수:"+totalPage);
//		
//		String cmd;
//		while(true) {
//			cmd = Ci.r("페이지번호입력[이전 메뉴로:x]:");
//			if(cmd.equals("x")) {
//				break;
//			}
//			currentPage = Integer.parseInt(cmd);
//			if(currentPage > totalPage || currentPage < 1) {
//				Cw.wn("페이지 범위에 맞는 값을 넣어주세요");
//				continue;
//			}
//
//			startIndex = (currentPage - 1) * PER_PAGE;	// 페이지의 첫 인덱스를 계산해서 저장하기
//			String sql = "select * from board limit "+startIndex+","+PER_PAGE;
//			try {
//				Cw.wn("전송한sql문:"+sql);
//				result = st.executeQuery(sql);
//				while(result.next()) {	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
//					String no = Db.result.getString("b_no");
//					String title = Db.result.getString("b_title");
//					String id = Db.result.getString("b_id");
//					String datetime = Db.result.getString("b_datetime");
//					Cw.wn(no+" "+title+" "+id+" "+datetime);
//				}
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}			
//			
//		}
//		
//
//
//	}
////	public static void menulistrun() {
////		
////		LocalDate now = LocalDate.now();
////		DataForBorad.date = now.toString();
////		int list_number = 0;
////		
////		for (int i = 0; i < BoradFunsion.countdata.size(); i++) {
////			Product list_all = BoradFunsion.listdata.get(i);
////			list_number = i + 1;
////			Cw.w("No." + list_number + " ");
////			Cw.w("제목:" + list_all.title + "/");
////			Cw.w("작성자:" + list_all.write + "/");
////			Cw.wn("조회수:" + DataForBorad.view_limit);
////			Cw.wn("작성일:" + DataForBorad.date);
////			Cw.wn("〓〓〓〓〓〓〓〓〓〓〓〓〓");
////			
////		}
////		
////	}
////	
////	public static void dellistrun() {
////		
////		int del_number = 0;
////		for (int i = 0; i < BoradFunsion.deldata.size(); i++) {
////			Product del_all = BoradFunsion.deldata.get(i);
////			del_number = i + 1;
////			Cw.w("No." + del_number + " ");
////			Cw.w("제목:" + del_all.title + "/");
////			Cw.w("작성자:" + del_all.write + "/");
////			Cw.wn("조회수:" + DataForBorad.view_limit);
////			Cw.wn("작성일:" + DataForBorad.date);
////			Cw.wn("〓〓〓〓〓〓〓〓〓〓〓〓〓");
////
////		}
////		
////	}
//	
//}