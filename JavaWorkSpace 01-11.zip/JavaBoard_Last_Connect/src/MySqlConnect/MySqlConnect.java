package MySqlConnect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import JavaFunsionData.BoradFunsion;
import JavaFunsionData.Product;
import Util.Cw;

public class MySqlConnect {
	public static Connection con = null;
	public static Statement st = null;
	public static ResultSet result = null;
	public static ResultSet result2 = null;

	public static void writerun(String xx) {
		dbExecuteUpdate(xx);
		System.out.println("글 등록 완료");
	}

	public static void readrun(String xx) {
		dbreadrun(xx);
		System.out.println("글 읽기 완료");
	}

	public static void editrun(String xx) {
		dbeditrun(xx);
		System.out.println("수정완료!");
	}

	public static void javaaddrun() {
		dbjavaaddrun();
	}

	public static void listrun(String xx) {
		dblistrun(xx);
		System.out.println("글리스트 입니다.");
	}

	public static void dbInit() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement(); // Statement는 정적 SQL문을 실행하고 결과를 반환받기 위한 객체다. Statement하나당 한개의 ResultSet 객체만을 열
										// 수있다.
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void dbExecuteUpdate(String query) {
		try {
			int resultCount = st.executeUpdate(query);
			System.out.println("데이터베이스에 업로드 된 글 갯수:" + resultCount);
		} catch (SQLException e) {
			e.printStackTrace();
//			System.out.println("SQLException: " + e.getMessage());
//			System.out.println("SQLState: " + e.getSQLState());
		}
	}

	private static void dbreadrun(String xx) {
		try {
			result = st.executeQuery(xx);
			result.next();
			String title = result.getString("b_title"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
			String content = result.getString("b_text");
			String writer = result.getString("b_id");
			System.out.println("글제목: " + title);
			System.out.println("글내용: " + content);
			System.out.println("작성자: " + writer);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void dblistrun(String xx) {
		try {
			String list = xx;
			result = st.executeQuery(list);
			
			while (result.next()) {

				String no = result.getString("b_no"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				String title = result.getString("b_title"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				String content = result.getString("b_text"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				String writer = result.getString("b_id"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				String datetime = result.getString("b_datetime"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				String b_hit = result.getString("b_hit"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)

				System.out.println(no + ".");
				System.out.println("글제목: " + title);
				System.out.println("글내용: " + content);
				System.out.println("작성자: " + writer);
				System.out.print("작성시간: " + datetime);
				System.out.println("조회수: " + b_hit);

			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void dbjavaaddrun() {
		try {

			String arraycon = "SELECT * FROM board";
			String arraycon2 = "SELECT * FROM board WHERE b_delnumber = 0";
//			String arraycon3 = "SELECT * FROM board WHERE b_delnumber = 1";

			
			PreparedStatement ps = con.prepareStatement(arraycon);
			PreparedStatement ps_v = con.prepareStatement(arraycon2);

			result = ps.executeQuery();
			result2 = ps_v.executeQuery();

			while (result.next()) {

				String board_title = result.getString("b_title");
				String board_text = result.getString("b_text");
				String board_write = result.getString("b_text");
				int board_no = result.getInt("b_delnumber");
				BoradFunsion.countdata.add(new Product(board_title, board_text, board_write, board_no));

			}
			while (result2.next()) {
				String board_title = result2.getString("b_title");
				String board_text = result2.getString("b_text");
				String board_write = result2.getString("b_text");
				BoradFunsion.listdata.add(new Product(board_title, board_text, board_write));
			}
			
			for (Product row : BoradFunsion.countdata) {
				System.out.println(row);
			}
			
			for (int i = 0; i < BoradFunsion.countdata.size(); i++) {
				BoradFunsion.BoradDataHash.put(i, BoradFunsion.countdata.get(i));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void dbeditrun(String xx) {
		try {
			int resultCount = st.executeUpdate(xx);
			System.out.println("처리된 행 수:" + resultCount);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	static public int dbPostCount() {
		String count = "";
		try {
			result = st.executeQuery("select count(*) from board");
			result.next();
			count = result.getString("count(*)");
			Cw.wn("글 수:"+count);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		int intCount = Integer.parseInt(count);
		return intCount;
	}
	
	
}