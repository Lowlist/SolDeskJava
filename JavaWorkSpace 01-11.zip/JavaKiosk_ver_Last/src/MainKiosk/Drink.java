package MainKiosk;

import CheckAndCash.MenuCheck;
import MenuInfo.DrinkData;
import MenuInfo.MainFunsion;
import MenuInfo.Product;
import Util.Cw;

public class Drink {

	//아래 함수를 선언하고 다른곳으로 불러오려면 java 파일명.n; 으로 선언하면 불러올수있음
	//드링크 화면 출력란
	public static void drinkinfo(){
		Cw.wn("--------드링크 메뉴---------");
		for(Product p:MainFunsion.drink) {	
			if(p instanceof DrinkData) {
				Cw.wn(p.number+"."+p.name+" ["+p.price +"]원");
			}
			
			
		}
		Cw.wn("-----------------------");
		drinkstrat:
		while(true) {
				Cw.wn("메인메뉴로 돌아가기[e] 메뉴 다시보기 [r]");
				Cw.wn("장바구니 비우기[c] 장바구니 확인[v]");
				Cw.wn("-----------------------");
				Cw.wn("드링크를 선택해주세요!");
				MainFunsion.cmd = MainFunsion.sc.next();
			switch(MainFunsion.cmd) {
				case "1":
					Cw.wn("뜨거운커피를 선택하셨습니다!");
					Cw.wn("----------------");
					DrinkSize.drinksize();
					MainFunsion.drink_T.add(MainFunsion.drink.get(0));
					break;
				case "2":
					Cw.wn("아이스커피를 선택하셨습니다!");
					Cw.wn("----------------");
					DrinkSize.drinksize();
					MainFunsion.drink_T.add(MainFunsion.drink.get(1));
					break;
				case "3":
					Cw.wn("딸기스무디를 선택하셨습니다!");
					Cw.wn("----------------");
					DrinkSize.drinksize();
					MainFunsion.drink_T.add(MainFunsion.drink.get(2));
					break;
				case "4":
					Cw.wn("복숭아스무디를 선택하셨습니다!");
					Cw.wn("----------------");
					DrinkSize.drinksize();
					MainFunsion.drink_T.add(MainFunsion.drink.get(3));
					break;
				case "r":
					for(Product p:MainFunsion.drink) {	//메뉴출력
						{	
						Cw.wn(p.number+"."+p.name+" ["+p.price +"]원");
						}
					}
					break;
				case "e":
					break drinkstrat;
				case "c":
					MainFunsion.drink_T.clear();
					MainFunsion.dessert_T.clear();
					break;
				case "v":
					MenuCheck.drinkcheckrun();
					break;
			}
			
		}

	}

}
	
