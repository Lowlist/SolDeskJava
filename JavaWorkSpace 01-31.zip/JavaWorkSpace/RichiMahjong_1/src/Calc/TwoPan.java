package Calc;

public class TwoPan {

}
