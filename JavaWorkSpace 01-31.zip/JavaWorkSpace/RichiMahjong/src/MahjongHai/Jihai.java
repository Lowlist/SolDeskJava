package MahjongHai;

public class Jihai {

	
	
	
}
