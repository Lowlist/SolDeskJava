package MahjongHai;

public class Sak {

}
