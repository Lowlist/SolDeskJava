package com.lowlist.Dao;

import java.util.ArrayList;

import com.lowlist.Db.Db;
import com.lowlist.Dto.L_Dto;

public class Dao extends Da{

	public void create_room() {
		try {
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	//채팅 저장문
	public ArrayList<L_Dto> chat_data(String room_name,String id_no,String chatrun){
		ArrayList<L_Dto> chatstart = new ArrayList<L_Dto>();
		try {
			// chatrun 임시용 채팅 내용 받아올곳
			// id 입시용 채팅한 사람 고유 아이디 받아올곳
			// chat_unique_no  현재 접속한 방 넘버
			
			chatstart.add(new L_Dto(chatrun,id_no,room_name));
			// 만약에 어레이리스트를 사용할꺼면 이거 넣으면 됌 안그러면 빼도 상관x
			String sql = String.format(
					"INSERT INTO %s (room_name,user_no,content,) VALUES ('%d','%d','%s',)"
					,Db.DB_TABLE,room_name,id_no,chatrun); // 포맷은 아니까 패스 
			super.update(sql); // Da 부모클래스에서 불러온 Update 문 이거 쓰면 자동으로 MySql 열림.
			super.close(); // 닫기
		}catch(Exception e){
			e.printStackTrace();
		}
		return chatstart;
	}
		

//	public ArrayList<Dto> chat
	
	
	
	
	
}
