package com.lowlist.Dto;

public class L_Dto {

	public String no;
	public String id;
	public String pw;
	public String name;
	public String name_num;

	public L_Dto(String id, String pw) {
		this.id = id;
		this.pw = pw;
	}

	public L_Dto(String no, String id, String pw, String name, String name_num) {
		this.no = no;
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.name_num = name_num;
	}

	public L_Dto(String id, String pw, String name) {
		this.id = id;
		this.pw = pw;
		this.name = name;
	}
	
}
