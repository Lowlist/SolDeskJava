create DATABASE My_cat default character set UTF8MB4;
show databases;

use my_cat;

create table board (
	b_no int primary key auto_increment, 	#글번호
	b_title char(100) not null,				#글제목
    b_id char(20) not null,					#작성자id
	b_datetime datetime not null,			#작성시간
    b_hit int default 0 not null,			#조회수    
    b_text text,							#글내용
    b_delnumber int default 0 not null,     #삭제여부
    b_commment char(30) default null,		#댓글
    b_postpw char(10) default null, 		#게시물비밀번호
    b_unique_no int unique default null			#아이디고유번호
    
);



create table idpw (
	b_no int primary key auto_increment,
    b_id char(50) unique,
	b_pw char(50) not null
    /*이거 나중할거임 */
-- 	   b_pw_check char(50) not null,
--     b_name char(50) not null,
--     b_nick_name char(10) not null,
--     b_address char(128) not null,
--     b_phone_number int not null,
--     b_email char(40) not null
    
);

desc board;
desc idpw;
drop table board;
insert into board (b_title,b_id,b_datetime,b_text) 
values (
'헬로'
,
'cat1'
,
now()
,
'글입니다. 글글.....글....'
);

drop table idpw;
select * from board;
delete from borad;
select * from board order by b_no desc;
update board set b_delnumber=1;
update board set b_hit=0;
select b_no as 글번호, b_title as 글제목, b_id as 작성자, b_datetime as 작성일, b_hit as 조회수, b_text as 내용 from board where b_delnumber =0; 
select b_no as 고유번호, b_id as 아이디, b_pw as 패스워드 from idpw;
update board set b_delnumber=0;
