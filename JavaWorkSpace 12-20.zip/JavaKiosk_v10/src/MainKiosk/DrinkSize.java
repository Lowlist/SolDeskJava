package MainKiosk;

import MenuInfo.MainFunsion;
import MenuInfo.Product;
import Util.Cw;

public class DrinkSize {
	//드링크 사이즈 출력
	
	public static void drinksize() {
	Cw.wn("드링크 사이즈를 골라주세요!");
	sizestart:
		while(true) { 
			for(Product ds : MainFunsion.drinksize) {
				Cw.wn(ds.number+"."+ds.name+" 사이즈 ["+ds.price +"]원");
			}
			System.out.println("주문취소[x]");
			MainFunsion.cmd = MainFunsion.sc.next();
		switch(MainFunsion.cmd) {
			case "1":
				Cw.wn("[톨]사이즈가 선택되었습니다!");
				MainFunsion.drink_T.add(MainFunsion.drinksize.get(0));
				Cw.wn("----------------");
				break sizestart;
			case "2":
				Cw.wn("[그단데]사이즈가 선택되었습니다!");
				MainFunsion.drink_T.add(MainFunsion.drinksize.get(1));
				Cw.wn("----------------");
				break sizestart;
			case "3":
				Cw.wn("[벤티]사이즈가 선택되었습니다!");
				MainFunsion.drink_T.add(MainFunsion.drinksize.get(2));
				Cw.wn("----------------");
				break sizestart;
			case "4":
				Cw.wn("[트렌타]사이즈가 선택되었습니다!");
				MainFunsion.drink_T.add(MainFunsion.drinksize.get(3));
				Cw.wn("----------------");
				break sizestart;
			case "x":
				Cw.wn("주문을 취소합니다.");
				break sizestart;
			}
	
		}		
		
	}
}

