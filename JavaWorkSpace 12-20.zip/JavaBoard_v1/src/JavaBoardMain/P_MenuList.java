package JavaBoardMain;

import JavaBoradData.BoradFunsion;
import JavaBoradData.Product;
import Util.Cw;

public class P_MenuList {
	
	static void menulistrun() {
		
		int list_number = 0;
		for(int i = 0 ; i<BoradFunsion.titledata.size() ; i++) {
			Product list_all = BoradFunsion.listdata.get(i); 
			list_number = i+1;
			Cw.w("No."+list_number);
			Cw.w("제목:"+list_all.title+"/");
			Cw.w("내용:"+list_all.content+"/");
			Cw.wn("작성자:"+list_all.write+"/");
			Cw.wn("〓〓〓〓〓〓〓〓〓〓〓〓〓");
		}
		
	}
	
}
