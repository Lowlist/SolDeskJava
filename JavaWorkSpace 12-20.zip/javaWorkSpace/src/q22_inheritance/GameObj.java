package q22_inheritance;


public class GameObj {
	//할아버지는 왕인데 나눠주기만 하는 왕
	//자식들은 패륜아라 다가져가서 쓸수있음
	
	String name;
	
	void info() {
		
		System.out.println("이름:"+ name);
		
	}
	
	
}
