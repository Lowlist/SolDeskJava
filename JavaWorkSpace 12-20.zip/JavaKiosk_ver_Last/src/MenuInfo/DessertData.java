package MenuInfo;

public class DessertData extends Product  {
	
	public DessertData(String xx, int yy, String aa) {
		super(xx,yy,aa);
	}
	

}
