package com.lowlist.dto.mapleapi;

import lombok.Data;

@Data
public class AbilityInfo {
	public String ability_no;
	public String ability_grade;
	public String ability_value;
}
