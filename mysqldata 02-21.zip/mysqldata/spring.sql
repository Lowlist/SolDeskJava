use my_cat;

create table tbl_test (		
	no int,	
	str_data varchar(50)	
);		

create table tbl_visitant_count (		
	no int,
	count int
);
drop table tbl_visitant_count;
insert into tbl_visitant_count values(0,0);
insert into tbl_test values(2,'2');
insert into tbl_test values(3,'100');
insert into tbl_test values(4,'HELLO WORLD');

select * from tbl_test;
select * from tbl_visitant_count;

create table tbl_guest(				
	bno int auto_increment primary key,			
	btext text			
);				
insert into tbl_guest (btext) values('개');				
insert into tbl_guest (btext) values('고양이');
select *from tbl_guest;
