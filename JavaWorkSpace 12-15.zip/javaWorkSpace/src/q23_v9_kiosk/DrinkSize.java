package q23_v9_kiosk;

public class DrinkSize extends MenuInfo {
	
	
	public static void drinksize() {
	System.out.println("드링크 사이즈를 골라주세요!");

	
//		while(true) { 더미코드 << 나중에 사이즈 재선택할때 만들꺼임
			si1.sizeinfo();
			si2.sizeinfo();
			si3.sizeinfo();
			si4.sizeinfo();
			cmd = sc.next();
			sizestart:
		switch(cmd) {
			case "1":
				si1.addsetsize();
				drinksize.add(si1);
				System.out.println("----------------");
				break;
			case "2":
				si2.addsetsize();
				drinksize.add(si2);
				System.out.println("----------------");
				break;
			case "3":
				si3.addsetsize();
				drinksize.add(si3);
				System.out.println("----------------");
				break;
			case "4":
				si4.addsetsize();
				drinksize.add(si4);
				System.out.println("----------------");
				break;
			case "x":
				System.out.println("주문을 취소합니다.");
				break sizestart;
			}
	
		}		
		
	}
	

