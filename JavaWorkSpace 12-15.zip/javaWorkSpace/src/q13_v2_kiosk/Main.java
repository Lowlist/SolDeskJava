package q13_v2_kiosk;

import java.util.Scanner;

public class Main {
	
	
	
}