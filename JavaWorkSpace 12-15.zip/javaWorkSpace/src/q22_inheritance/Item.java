package q22_inheritance;

public class Item extends GameObj {
	
	int weight;
	int 수명;
}
