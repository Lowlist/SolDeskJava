package q22_inheritance;

public class Character extends GameObj{
	
	int hp;
	int attack;

}
