CREATE DATABASE my_dog default CHARACTER SET UTF8MB4;
use my_dog;

select * from dog_board;
create table dog_board(
	num int primary key auto_increment, 
    title char(255),
    content text,
    id char(30),
    del_number int not null default 0 
);

insert into dog_board values(0,'테스트제목','테스트내용 내용.......','cat4',0);
insert into dog_board values(0,'테스트제목2','테스트내용2 내용.......2','dog3',0);
	

drop table dog_board;