package MySqlConnect;

import JavaFunsionData.BoradFunsion;

public class PostCount {

	public static void clearborad() {
		BoradFunsion.countdata.clear();
		BoradFunsion.listdata.clear();
		BoradFunsion.delCount.clear();
		BoradFunsion.BoradDataHash.clear();
	}
	public static void clearidpw() {
		BoradFunsion.idcount.clear();
		BoradFunsion.idPwData.clear();
		BoradFunsion.PwData.clear();
		BoradFunsion.idPwDataHash.clear();
	}
	
}
