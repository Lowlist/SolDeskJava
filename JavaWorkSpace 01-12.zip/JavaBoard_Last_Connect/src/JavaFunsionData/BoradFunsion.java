package JavaFunsionData;

import java.util.ArrayList;
import java.util.HashMap;

public class BoradFunsion {

	//카운트 데이터
	public static ArrayList<Product> countdata = new ArrayList<Product>();
	//통합 리스트
	public static ArrayList<Product> listdata = new ArrayList<Product>();
	//삭제 리스트
	public static ArrayList<Product> delCount = new ArrayList<Product>();
	//아이디 리스트
	public static ArrayList<String> idcount = new ArrayList<String>();
	public static ArrayList<String> PwData = new ArrayList<String>();
	public static ArrayList<Product> idPwData = new ArrayList<Product>();
	
	//해쉬맵 리스트
//	public static HashMap<String,HashMap<String,String> > loginDataHash = new HashMap<>();
	public static HashMap<String,String> idPwDataHash = new HashMap<>();
	public static HashMap<Integer,Product> BoradDataHash = new HashMap<>();
	
	
}
