package JavaFunsionData;

import java.util.Map;

public class CalcHashMap {
	public static Product del_numbercalc;
	public static void calcrun() {
	for(Map.Entry<Integer,Product> borad_data : BoradFunsion.BoradDataHash.entrySet()) {
			Product cc = borad_data.getValue();
			del_numbercalc = cc;
		}
	}
	public static void calcfor() {
		for(int i = 0;i<BoradFunsion.countdata.size();i++) {
		}
		return;
	}
}
