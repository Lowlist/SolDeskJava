package JavaBoardDelAndEdit;

import java.util.Scanner;

import JavaBoardAndWriteAndRead.P_MenuList;
import JavaFunsionData.BoradFunsion;
import JavaFunsionData.CalcHashMap;
import MySqlConnect.MySqlConnect;
import MySqlConnect.PostCount;
import Util.Cw;

public class P_MenuDel {

	public static void menudelrun() {

		Scanner sc = new Scanner(System.in);
		Cw.wn("작성한 게시물을 삭제하는 곳입니다.");
		int read_number = 0;
		if (!BoradFunsion.listdata.isEmpty()) {
			P_MenuList.menulistrun("[번호입력]페이지넘기기 [삭제메뉴:x]");
			Cw.wn("삭제할 게시물 번호를 입력하세요");
			CalcHashMap.calcrun();
			String input = sc.nextLine();

			// gpt 님의 코드입니다.

			try {
				int del_numbers = Integer.parseInt(input); // 문자열을 숫자로 변환

					if (del_numbers > 0 && del_numbers <= BoradFunsion.countdata.size()) {
				
						for(int i = 0;i<BoradFunsion.countdata.size();i++) {
							
							if(BoradFunsion.BoradDataHash.get(i).del_number==0) {
								
								// 입력된 번호가 게시물 범위 내에 있는지 확인
								//System.out.println("제목:"+hashtitle.title +" 글을 삭제하였습니다.");
								
								String dbdel = "UPDATE board SET b_delnumber = 1 WHERE b_no="+del_numbers;
								MySqlConnect.writerun(dbdel);
								PostCount.clearborad();
								MySqlConnect.javaaddrun();
								break;
								}
							if(BoradFunsion.BoradDataHash.get(del_numbers-1).del_number==1) {
								System.out.println("게시물이 존재하지 않습니다!");
								break;
							}
							}
						
						}else {
						System.out.println("게시글 넘버를 제대로 입력해주세요!");
					}
					
			}catch (NumberFormatException e) {
				System.out.println("유효한 입력이 아닙니다.");
			}

		} else {
			Cw.wn("저장된 글이 없습니다!");
		}

	}
}
