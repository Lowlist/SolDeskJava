package com.lowlist.JavaBoardSearch;

import java.util.Map;
import java.util.Scanner;

import com.lowlist.Dao.MySqlConnect;
import com.lowlist.Dao.P_BoradClear;
import com.lowlist.JavaBoardIdProcess.P_IdCheck;
import com.lowlist.JavaBoardNonID.P_MenuNonIdComment;
import com.lowlist.JavaBoardPostID.P_MenuIdComment;
import com.lowlist.JavaFunsionData.BoradFunsion;
import com.lowlist.JavaFunsionData.Product;
public class P_PostSearch {


		public static void idcommentruns() {
			int cmd_no;
			Scanner sc = new Scanner(System.in);
			if (!BoradFunsion.listdata.isEmpty()) {
				boolean commentchek = false;
				System.out.println("게시판 제목과 내용으로 특정게시판을 찾을수가 있는곳 입니다!");
				System.out.println("검색할 게시판을 입력해주세요!!");
				String cmd_select = sc.nextLine();
				
				try {
					
					int select_borad = Integer.parseInt(cmd_select);

					if (select_borad > 0 && select_borad <= BoradFunsion.countdata.size()) {

						for (int i = 0; i < BoradFunsion.countdata.size(); i++) {
							if (BoradFunsion.BoradDataHash.get(select_borad - 1).del_number == 1) {
								if (!commentchek) {
									System.out.println("게시물이 존재하지 않습니다!");
									break;
								} else {
									System.out.println("댓글작성완료!");
									break;
								}
							}
							
							if (BoradFunsion.BoradDataHash.get(i).del_number == 0) {
								//아이디 입력했을때 출력
								if(P_IdCheck.Unique_number != 0) {
									// 재원이형이 알려줬는데 set 여러개 하려면 컴마넣으면 됨 
									
									P_MenuIdComment.menuidcommentrun(select_borad);
									String commentcount = "UPDATE board SET b_comment = b_comment+1 WHERE b_no=" + cmd_select;
									MySqlConnect.editrun(commentcount);
									
									P_BoradClear.clearborad();
									MySqlConnect.javaaddrun();
									System.out.println("댓글작성완료!");
									commentchek = true;
									break;
								}
								//아이디 없을때 출력
								if(P_IdCheck.Unique_number == 0) {
									
									P_MenuNonIdComment.menunonidcommentrun(select_borad);
									String commentcount = "UPDATE board SET b_comment = b_comment+1 WHERE b_no=" + cmd_select;
									MySqlConnect.editrun(commentcount);
									
									P_BoradClear.clearborad();
									MySqlConnect.javaaddrun();

									System.out.println("댓글작성완료!");
									commentchek = true;
									break;
								}
								break;
							}
					}
				}else {
					System.out.println("유효한 게시물 범위가 아닙니다!");
				}
					
				} catch (NumberFormatException e) {
					System.out.println("유효한 입력이 아닙니다.");
				}
			}

		}
	}
	
	
	
	
	
