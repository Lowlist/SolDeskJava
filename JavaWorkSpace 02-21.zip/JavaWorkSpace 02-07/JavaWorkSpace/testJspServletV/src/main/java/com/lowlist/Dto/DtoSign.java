package com.lowlist.Dto;

public class DtoSign {
	
	
	public String no;
	public String id;
	public String pw;
	public int loginno = 0;
	
	public DtoSign(String id, String pw) {
		this.id = id;
		this.pw = pw;
	}
	public DtoSign(int loginno,String id) {
		this.loginno = loginno;
		this.id = id;
	}
}
