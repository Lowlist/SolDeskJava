package Calc;

public class Mangan {

}
