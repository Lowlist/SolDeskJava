package MahjongHai;

import MainFunsion.FunsionList;
import MainFunsion.Product;

public class HaiAll {

	public static void haiallrun() {
		
	String sak = "삭";
	String tong = "통";
	String man = "만";
	String dong = "동";
	String nam = "남";
	String sue = "서";
	String buk = "북";
	String back = "백";
	String bal = "발";
	String jung = "중";

		FunsionList.hainame.add(new Product(sak));
		FunsionList.hainame.add(new Product(tong));
		FunsionList.hainame.add(new Product(man));
		FunsionList.hainame.add(new Product(dong));
		FunsionList.hainame.add(new Product(nam));
		FunsionList.hainame.add(new Product(sue));
		FunsionList.hainame.add(new Product(buk));
		FunsionList.hainame.add(new Product(back));
		FunsionList.hainame.add(new Product(bal));
		FunsionList.hainame.add(new Product(jung));
	
	}
	
}
