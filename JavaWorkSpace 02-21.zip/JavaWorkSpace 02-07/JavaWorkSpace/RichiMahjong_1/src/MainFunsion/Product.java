package MainFunsion;

public class Product {
	
	int Hai_no = 0;
	
	String Hai_name;
		
	public Product(int a){
		a=Hai_no;
	}
	
	public Product(String a){
		a=Hai_name;
	}
}
