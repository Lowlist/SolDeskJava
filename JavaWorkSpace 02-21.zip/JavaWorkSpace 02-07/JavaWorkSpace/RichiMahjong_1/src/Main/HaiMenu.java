//package Main;
//
//import java.util.Scanner;
//
//import MahjongHai.HaiAll;
//import MainFunsion.FunsionList;
//import MainFunsion.Product;
//
//public class HaiMenu {
//
//	public void haimenurun() {
//		Scanner sc = new Scanner(System.in);
//		HaiAll.haiallrun();
//		start:
//		while (true) {
//
//			System.out.println("패를 입력해주세요");
//			String cmd = sc.nextLine();
//			String nowhai = cmd;
//			
//			System.out.println("");
//			
//			for(int i = 0 ; i < FunsionList.hainame.size(); i++) {
//			if(nowhai.equals(FunsionList.hainame.get(i)) ) {
//			FunsionList.hainame.add(new Product(nowhai));
//			}else()
//			if (nowhai.length() >= 14) {
//				break start;
//			}
//			}
//		}
//		System.out.println("다찼음");
//
//	}
//
//}
