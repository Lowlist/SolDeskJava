package testjspboardre;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ReturnDB {

	private static final String JDBC_URL = "jdbc:mysql://localhost:3306/my_dog";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "root";

    //throws 는 떠넘기기 전에 배웠음
	    public static Connection getConnection() throws SQLException {
	        return DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
	    }
	    
	    public static ResultSet executeQuery(String sql) {
	        try (Connection connection = getConnection();
	        	PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
	            return preparedStatement.executeQuery();

	        } catch (SQLException e) {
	            e.printStackTrace();
	            System.out.println("연결실패");
	        }

	        return null;
	    }
	    
}
