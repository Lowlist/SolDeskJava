CREATE DATABASE tottenham default CHARACTER SET UTF8MB4;
show databases;
use Tottenham;

drop table member;
select * from member;

create table member(
backnumber int primary key,
playername char(20) unique not null,
position char(30) not null
);
-- 공격수 -- 
insert into member(backnumber,playername,position) values
('22','브레넌 존슨','공격수'),
('7','손흥민','공격수'),
('36','알레호 벨리스','공격수'),
('14','이반 페리시치','공격수'),
('63','제이미 돈리','공격수'),
('9','히샬리송','공격수');

-- 미드필더 -- 
insert into member(backnumber,playername,position) values
('21','데안 쿨루셰프스키','미드필더'),
('19','라이언 세세뇽','미드필더'),
('30','로드리고 벤탕쿠르','미드필더'),
('27','마노르 솔로몬','미드필더'),
('11','브리안 힐 살바티에라','미드필더'),
('58','야고 산티아고','미드필더'),
('4','올리버 스킵','미드필더'),
('8','이브스 비수마','미드필더'),
('10','제임스 메디슨','미드필더'),
('18','지오바니 로셀소','미드필더'),
('29','파페 마타르사르','미드필더'),
('5','피에르 호이비에르','미드필더');

-- 수비수 --  
insert into member(backnumber,playername,position) values
('38','데스티니 우도지','수비수'),
('37','미키 판 더 펜','수비수'),
('33','벤 데이비스','수비수'),
('65','알피 도링턴','수비수'),
('35','애슐리 필립스','수비수'),
('15','에릭 다이어','수비수'),
('12','이메르송','수비수'),
('17','크리스티안 로메로','수비수'),
('23','페드로 포로','수비수');

-- 골키퍼 --  
insert into member(backnumber,playername,position) values
('13','굴리엘모 비카리오','미드필더'),
('40','브랜든 오스틴','미드필더'),
('41','알피 화이트맨','미드필더'),
('1','위고 요리스','미드필더'),
('20','프레이저 포스터','미드필더');






