package q08;

import q08.lotto;

public class main {
	
	public static void main(String[] args) {
		lotto r = new lotto();
		r.run();
	}
}
