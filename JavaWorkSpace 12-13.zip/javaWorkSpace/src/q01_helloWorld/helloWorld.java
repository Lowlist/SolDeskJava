package q01_helloWorld;

public class helloWorld {

	public static void main(String[] args){
		System.out.println("��ο���");
	}
	
}
