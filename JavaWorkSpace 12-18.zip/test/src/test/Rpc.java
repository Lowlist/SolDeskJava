package test;

import java.util.ArrayList;

import java.util.Scanner;

public class Rpc {

	static public int roll(int n) {
		int r = (int) (Math.random() * n + 1);
		return r;
	}

	static void run() {
		ArrayList<String> logwin = new ArrayList<String>();
		ArrayList<String> loglose = new ArrayList<String>();
		ArrayList<String> logdraw = new ArrayList<String>();
		Scanner sc = new Scanner(System.in);

		System.out.println("가위바위보 게임에 오신걸 환영합니다!");
		System.out.println("조작키: '가위' '바위' '보' 입력");
		System.out.println("w: 승리한횟수 l:패배한횟수 d:비긴횟수");
		System.out.println("b: 조작키다시보기 x: 게임종료 c:기록초기화");

		start:
			while (true) {
			String cmd = sc.next();
			System.out.println("가위,바위,보 중 한개를 입력하세요!");
			switch (cmd) {
			case "가위":
				System.out.println("Player: 가위");
				switch (roll(3)) {
				case 1:
					System.out.println("Com: 가위");
					System.out.println("비김");
					logdraw.add("비김");
					break;
				case 2:
					System.out.println("Com:바위");
					System.out.println("패배");
					loglose.add("패배");
					break;
				case 3:
					System.out.println("Com:보");
					System.out.println("승리");
					logwin.add("승리");
					break;
				}
			}
			switch (cmd) {
			case "바위":
				System.out.println("Player: 바위");
				switch (roll(3)) {
				case 1:
					System.out.println("Com:가위");
					System.out.println("승리");
					logwin.add("승리");
					break;
				case 2:
					System.out.println("Com:바위");
					System.out.println("비김");
					logdraw.add("비김");
					break;
				case 3:
					System.out.println("Com:보");
					System.out.println("패배");
					loglose.add("패배");
					break;
				}
			}
			switch (cmd) {
			case "보":
				System.out.println("Player: 보");
				switch (roll(3)) {
				case 1:
					System.out.println("Com:가위");
					System.out.println("패배");
					loglose.add("패배");
					break;
				case 2:
					System.out.println("Com:바위");
					System.out.println("승리");
					logwin.add("승리");
					break;
				case 3:
					System.out.println("Com:보");
					System.out.println("비김");
					logdraw.add("비김");
					break;
				}
			}
			switch (cmd) {
			case "w":
				System.out.println("승리횟수: " + logwin.size());
				break;
			case "l":
				System.out.println("패배횟수: " + loglose.size());
				break;
			case "d":
				System.out.println("비긴횟수: " + logdraw.size());
				break;
			case "c":
				System.out.println("기록을 전부 초기화 합니다.");
				logwin.clear();
				loglose.clear();
				logdraw.clear();
				break;
			case "b": {
				System.out.println("조작키: '가위' '바위' '보' 입력");
				System.out.println("w: 승리한횟수 l:패배한횟수 d:비긴횟수");
				System.out.println("b: 조작키다시보기 x: 게임종료 c:기록초기화");
				break;
			}
			case "x":
				System.out.println("게임을 종료합니다");
				logwin.clear();
				loglose.clear();
				logdraw.clear();
				break start;
			}
		}

	}
}
