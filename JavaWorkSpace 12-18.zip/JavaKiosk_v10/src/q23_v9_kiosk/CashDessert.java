package q23_v9_kiosk;

public class CashDessert extends MenuInfo {
	//디저트 장바구니 출력란
	public static void cash_dessertrun(){
		
		int countCake = 0;
		int countMacaron = 0;
		int countSandwich = 0;
		
		for(int i = 0;i<dessert.size();i++) {
			Product dessertItem = dessert.get(i);
			drdeds_T.add(dessertItem);
			
			if (dessertItem.name.equals("케이크")) {
				countCake++;
            }
            if (dessertItem.name.equals("마카롱")) {
            	countMacaron++;
            }
            if (dessertItem.name.equals("샌드위치")) {
            	countSandwich++;
            }
			
			
		}
		if (!drdeds_T.isEmpty()) {
		    for (int i = 0; i < drdeds_T.size(); i++) {
		        Product q = drdeds_T.get(i);
		        q.showbarket();
		    }
		    System.out.println("============================");
            System.out.println("케이크:[" + countCake +"]");
            System.out.println("마카롱:[" + countMacaron+"]");
            System.out.println("샌드위치:[" + countSandwich+"]");
            System.out.println("============================");
		} else {
		    System.out.println("장바구니가 비어있습니다!");
		}

	}
}
