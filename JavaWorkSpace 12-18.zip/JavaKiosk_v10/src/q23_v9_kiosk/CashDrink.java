package q23_v9_kiosk;

public class CashDrink extends MenuInfo {
    // 드링크 장바구니 출력란
	// 챗 gpt가 알려줬음 카운트하는법
	// 몰랐던 부분 Product (a) = (n).get(); 부분
	// 변수 선언후 for문을 돌렸을때 if 를 넣으면 for 1바퀴마다 if문이 한번씩 실행되던부분
    public static void cashrun() {
        int countHotCoffee = 0;
        int countIceCoffee = 0;
        int countIchigo = 0;
        int countMomo = 0;

        for (int i = 0; i < drink.size(); i++) {
            Product drinkItem = drink.get(i);
            Product drinkSizeItem = drinksize.get(i);
            
//            Product (a) = (n).get(); 부분
//            메모리 개념 Product에 저장되어있는 (n)배열을 불러와 (a) 변수에 할당함
//            drinkItem,drinkSizeItem 변수 자체는 스택메모리에 저장되지만
//            drink.get(i),drinksize.get(i); 는 Product의 저장되어있는 힙 메모리 이기때문에
//            drinkItem,drinkSizeItem 변수는 힙 내부의 Product를 가르키는 형태가 됨.
            
            drink_T.add(drinkItem);
            drink_T.add(drinkSizeItem);

            if (drinkItem.name.equals("뜨거운커피")) {
                countHotCoffee++;
            }
            if (drinkItem.name.equals("아이스아메리카노")) {
            	countIceCoffee++;
            }
            if (drinkItem.name.equals("딸기스무디")) {
            	countIchigo++;
            }
            if (drinkItem.name.equals("복숭아스무디")) {
            	countMomo++;
            }

        }

        if (!drink_T.isEmpty()) {
            for (int i = 0; i < drink_T.size(); i++) {
                Product p = drink_T.get(i);
                p.showbarket(); 
            }
            System.out.println("============================");
            System.out.println("뜨거운커피:[" + countHotCoffee +"]");
            System.out.println("아이스아메리카노:[" + countIceCoffee+"]");
            System.out.println("딸기스무디:[" + countIchigo+"]");
            System.out.println("복숭아스무디:[" + countMomo+"]");
            System.out.println("============================");
        } else {
            System.out.println("장바구니가 비어있습니다!");
        }
    }
}
