package q03;

//import q11.Dice;

public class Main {

	public static void main(String[] args) {
		Rpc r = new Rpc();
		r.run();
	}
}
