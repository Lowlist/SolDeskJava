package q09;

public class main {
	
	public static void main(String[] args) {
		lotto lotto9 = new lotto();
		lotto9.run2();
	}
}
