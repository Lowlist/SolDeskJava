package JavaBoardCommon;

public class SourceForMain {

}
