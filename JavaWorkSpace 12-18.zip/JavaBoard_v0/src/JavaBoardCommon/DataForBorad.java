package JavaBoardCommon;

public class DataForBorad {

}
