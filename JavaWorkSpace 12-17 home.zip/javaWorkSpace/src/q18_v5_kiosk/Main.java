package q18_v5_kiosk;

public class Main {
	public static void main(String[] args) {
		Kiosk a= new Kiosk();
		a.run();
	}
	
}
