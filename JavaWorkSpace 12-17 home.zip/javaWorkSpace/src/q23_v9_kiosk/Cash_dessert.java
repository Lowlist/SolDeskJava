package q23_v9_kiosk;

public class Cash_dessert extends MenuInfo {
	
	public static void cash_dessertrun(){
	
		for(int i = 0;i<dessert.size();i++) {
			drdeds_T.add(dessert.get(i));	
		}
		for(int i = 0;i<drdeds_T.size();i++) {
			Product q = drdeds_T.get(i);
			q.showbarket();
//			if(!drdeds_T.isEmpty()) {
//			}else {
//				System.out.println("드링크,디저트 중 한개가 비어있으면 출력되지 않습니다.");
//			}
		}
	}
}
