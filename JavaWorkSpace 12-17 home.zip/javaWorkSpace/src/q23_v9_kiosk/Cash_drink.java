package q23_v9_kiosk;

public class Cash_drink extends MenuInfo{

	public static void cashrun() {
		
		for(int i = 0;i<drink.size();i++) {
			drink_T.add(drink.get(i));
			drink_T.add(drinksize.get(i));
		}
		
		for(int i = 0;i<drink_T.size();i++) {
		Product p = drink_T.get(i);
		p.showbarket();
		}
	}

}