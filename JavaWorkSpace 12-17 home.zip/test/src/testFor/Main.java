package testFor;

import java.util.ArrayList;

public class Main {
	
	public static void main(String[] args) {
		ArrayList<String> ac = new ArrayList<String>();
		ac.add("고양이");
		ac.add("개");
		ac.add("너구리");
		ac.add("바보");
		ac.add("멍청이");

		for(String s : ac) {//  향상된 포문 우측은 덩어리 왼쪽은 낱개 (변수선언문으로만 int,String...etc 형의 맞춰서)
			System.out.println(s);
//			배열을 >> 여기에 다 넣는 느낌
			
		}
	}
}