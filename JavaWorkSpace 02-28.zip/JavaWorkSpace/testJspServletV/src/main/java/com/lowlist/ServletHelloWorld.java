package com.lowlist;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lowlist.Dao.Dao;
import com.lowlist.Dto.DtoSign;

//@WebServlet("/ServletHelloWorld")
//public class ServletHelloWorld extends HttpServlet {
//	@Override
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		
//		//		response.getWriter().append("Served at: ").append(request.getContextPath());
//		
//		PrintWriter out = response.getWriter();
//		out.println("hello world");
//		String s = request.getParameter("id");
//		String b = request.getParameter("pw");
//		out.println(s);
//		out.println(b);
//		
//		System.out.println("==== 두 겟");
//		System.out.println("id: "+ request.getParameter("id"));
//		System.out.println("pw: "+ request.getParameter("pw"));
//		response.sendRedirect("list.jsp");
//		
//	}
//	
//}
@WebServlet("/ServletHelloWorld")
public class ServletHelloWorld extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		
		Dao login_add = new Dao();
		
		if(login_add.login_run(id, pw)) {
		    HttpSession session = request.getSession();
		    session.setAttribute("idkey", id);
		    session.setMaxInactiveInterval(360);
		    response.sendRedirect("list.jsp");
		} else {
		    System.out.println("id, pw 불일치");
		    response.sendRedirect("index.html");
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out =response.getWriter();
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		
		DtoSign sign_up_load = new DtoSign(id,pw);
		Dao sign_up_add = new Dao();
		
		System.out.println("------------------");
		System.out.println(sign_up_load.id);
		System.out.println(sign_up_load.pw);
		
		if(id == null && pw == null || id.equals("null") && pw.equals("null")) {
			System.out.println("꺼져");
			response.sendRedirect("index.html");
		}else {
			System.out.println("잘댐");
			sign_up_add.signup(sign_up_load);
			response.sendRedirect("index.html");
			out.println("바보");
		}
		
	}
}
