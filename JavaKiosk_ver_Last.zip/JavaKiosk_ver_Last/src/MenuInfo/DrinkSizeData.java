package MenuInfo;

public class DrinkSizeData extends Product {
	
	public DrinkSizeData(String xx, int yy, String aa) {
		super(xx, yy, aa);
	}
	
	
	
}
