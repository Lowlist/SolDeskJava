package JavaBoardMain;

import java.util.Scanner;

public class P_MenuDel {

	public static void menudelrun() {
		Scanner sc = new Scanner(System.in);
	}
	}
