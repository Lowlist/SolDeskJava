package q22_inheritance;

public class Sword extends Item {
		int attack;
}
