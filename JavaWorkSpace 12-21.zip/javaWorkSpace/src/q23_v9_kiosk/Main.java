package q23_v9_kiosk;

public class Main {
	//메인
	public static void main(String[] args) {
		
	Kiosk a = new Kiosk();
	
	a.run();
	
	}	
}
