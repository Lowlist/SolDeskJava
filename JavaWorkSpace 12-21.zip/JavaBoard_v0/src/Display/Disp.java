package Display;

import JavaBoradData.DataForBorad;
import Util.Cw;

public class Disp {
	public static void title() {
		Cw.line();
		Cw.dot();
		Cw.space(17);
		Cw.w(DataForBorad.TITLE);
		Cw.space(17);
		Cw.dot();
		Cw.wn();
		Cw.line();
	}
	public static void menuMain() {
		Cw.dot();
		Cw.space(13);
		Cw.w("[1.글 리스트/2.글수정/3.글쓰기/4.글삭제/e.종료]");
		Cw.space(13);
		Cw.dot();
		Cw.wn();
	}

}
