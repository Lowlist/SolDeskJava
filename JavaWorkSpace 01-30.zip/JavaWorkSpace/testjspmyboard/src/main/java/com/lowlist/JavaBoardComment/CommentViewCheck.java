package com.lowlist.JavaBoardComment;


import java.util.Scanner;

import com.lowlist.Dao.MySqlConnect;
import com.lowlist.JavaFunsionData.BoradFunsion;
public class CommentViewCheck {

		public static void commentviewchek() {
			
			Scanner sc = new Scanner(System.in);
			if (!BoradFunsion.listdata.isEmpty()) {
				boolean commentchek = false;
				System.out.println("댓글을 볼 수 있는곳 입니다!");
				System.out.println("댓글을 볼 게시물 번호를 입력해주세요!");
				String cmd_select = sc.nextLine();

				try {
					int select_borad = Integer.parseInt(cmd_select);

					if (select_borad > 0 && select_borad <= BoradFunsion.countdata.size()) {

						for (int i = 0; i < BoradFunsion.countdata.size(); i++) {
							if (BoradFunsion.BoradDataHash.get(select_borad - 1).del_number == 1) {
								if (!commentchek) {
									System.out.println("게시물이 존재하지 않습니다!");
									break;
								} else {
									System.out.println("댓글작성완료!");
									break;
								}
							}
							if (BoradFunsion.BoradDataHash.get(i).del_number == 0) {
								//아이디 입력했을때 출력
								String comment_view = "select * from commentall where b_connect_comment ="+select_borad;
								MySqlConnect.commentview(comment_view);
								break;
								}
							}
				}else {
					System.out.println("유효한 게시물 범위가 아닙니다!");
				}
					
				} catch (NumberFormatException e) {
					System.out.println("유효한 입력이 아닙니다.");
				}
			}
		}
	}

