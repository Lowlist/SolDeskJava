package com.lowlist;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//@WebServlet("/ServletHelloWorld")
//public class ServletHelloWorld extends HttpServlet {
//	@Override
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		
//		//		response.getWriter().append("Served at: ").append(request.getContextPath());
//		
//		PrintWriter out = response.getWriter();
//		out.println("hello world");
//		String s = request.getParameter("id");
//		String b = request.getParameter("pw");
//		out.println(s);
//		out.println(b);
//		
//		System.out.println("==== 두 겟");
//		System.out.println("id: "+ request.getParameter("id"));
//		System.out.println("pw: "+ request.getParameter("pw"));
//		response.sendRedirect("list.jsp");
//		
//	}
//	
//}
// 내일 서블릿 전송하는거 해볼꺼임@@@@@@@@@@@@@@@@@@@@@@@@
@WebServlet("/ServletHelloWorld")
public class ServletHelloWorld extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		
		System.out.println(request.getParameter("id"));
		System.out.println(request.getParameter("pw"));
		
		
		if(id.equals("cat") && pw.equals("1234")) {
			HttpSession session = request.getSession();
			session.setAttribute("idkey", id);
//			response.sendRedirect("list.jsp");
			response.sendRedirect("index.jsp");
			session.setMaxInactiveInterval(30);
		}else {
			System.out.println("id,pw비일치");
			response.sendRedirect("index.jsp");
		}
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		System.out.println(request.getParameter("id"));
		System.out.println(request.getParameter("pw"));
	}
	
	
}
