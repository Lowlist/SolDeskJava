package com.lowlist.hello;

public class Cat {
	public String catname = "고양이혐오생길꺼같아";
}
