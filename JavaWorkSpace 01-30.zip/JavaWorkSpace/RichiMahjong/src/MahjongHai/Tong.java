package MahjongHai;

public class Tong {

}
