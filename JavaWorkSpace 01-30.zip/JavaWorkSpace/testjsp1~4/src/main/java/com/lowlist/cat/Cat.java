package com.lowlist.cat;

public class Cat {

	public static String catname = "고양이만하니까 너무햇喝림진짜 바꿔줬으면좋겠음";
}
