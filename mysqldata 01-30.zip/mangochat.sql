# 칼럼명이 겹치는건 똑같은거 활용하는것임

CREATE DATABASE chat DEFAULT CHARACTER SET UTF8MB4;
use chat;
CREATE TABLE login(
user_no int primary key auto_increment, # 유저 고유 넘버
id char(30) unique, # 유저 아이디
pw char(30) , # 유저 비밀번호
user_name char(30), # 유저 닉네임
user_tag int default 1, # 유저 태그번호(중복일떄 1씩 증가
createdAt datetime not null default now(),
updatedAt datetime not null default now() on update now()
);

CREATE TABLE chatroom( 
room_no int primary key auto_increment, # 채팅방 고유번호
room_name char(50), # 채팅방 이름
room_stat int default 0, # 0일때 오픈방 1일때 닫힌방
user_max int default 10, # 맴버 최대 인원수
createdAt datetime not null default now(),
updatedAt datetime not null default now() on update now()
);

CREATE TABLE chatjoin( # 아이디 랑 채팅방이랑 링크하는 테이블
user_no int, 
room_no int,
content text,
createdAt datetime not null default now(),
updatedAt datetime not null default now() on update now()
);

CREATE TABLE chattingroom_no( # 이름은 변동사항임
 chat_no int,
 id_no int,
 chat char(50),
 time datetime not null default now()
);

CREATE TABLE Friends_List(
my_user_no int,
freind_user_no int,
freind int default 0
);


