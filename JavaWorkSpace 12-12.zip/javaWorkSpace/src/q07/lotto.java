package q07;

public class lotto {

	int rotto[] = new int[6];
	int r = (int)(Math.random()*6 + 1);
	int rn = (int)(Math.random()*45 +1);
	
	rotto[0] = rn;
	
	while(true) {
		
		switch(r) {
			case 1:
				System.out.println(rotto);
				
		
		
	}
}
