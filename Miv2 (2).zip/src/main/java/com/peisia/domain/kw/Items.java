
package com.peisia.domain.kw;

import java.util.List;

import lombok.Data;

@Data
public class Items {

    public List<Item> item;

}
