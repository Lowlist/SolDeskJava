
package com.peisia.domain.kw;

import lombok.Data;

@Data
public class Header {

    public String resultCode;
    public String resultMsg;

}
