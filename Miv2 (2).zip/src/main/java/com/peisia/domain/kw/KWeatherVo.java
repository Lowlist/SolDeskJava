
package com.peisia.domain.kw;

import lombok.Data;

@Data
public class KWeatherVo {

    public Response response;

}
