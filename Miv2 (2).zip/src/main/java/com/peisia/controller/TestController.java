package com.peisia.controller;

import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.peisia.domain.kw.KWeatherVo;
import com.peisia.service.TestService;
import com.peisia.spring.dto.TestDto;

import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/test/*")
//@AllArgsConstructor
@Controller
public class TestController {
	@Autowired
	private TestService service;
	
	@GetMapping("/getOnePlusTwo")
	public void getOnePlusTwo(Model model) {
//	public void getOnePlusTwo() {
		log.info("getOnePlusTwo ==========================================");
		String one = service.getOne();
		String two = service.getTwo();
		Integer sum = Integer.parseInt(one) + Integer.parseInt(two); 
		
		log.info("(여기 컨트롤러임) 1 더하기 2는 = " + sum);
		
		model.addAttribute("sum",sum);
	}

	@GetMapping("/updateVisitantCount")
	public void updateVisitantCount(Model model) {	
		
		log.info("updateVisitantCount ==========================================");
		TestDto wto = service.selectCount(0);
		if(0!=wto.getNo()) {
		TestDto one = service.insertCount(0,0);
		log.info("(인서트문)" + one.getNo());
		}
		Integer count = service.updateCount(0,wto.getCount());
		model.addAttribute("Count",count);
	}
	@GetMapping("/w")											
	public void w(Model model) {											
		//// 우리나라 공공 api ////										
		//인코딩 인증키										
		String API_KEY = "6Qg%2BHDGcsOCmPG7E4s4yFIrV2SIqLYL0gh4b7S6AJNTt9a3pkJ5379Lvcn1PmhBrSYZVdIKs6SmGDUSzB3R6Nw%3D%3D";										
		String API_URL = "http://apis.data.go.kr/1360000/AsosDalyInfoService/getWthrDataList?numOfRows=10&pageNo=1&dateCd=DAY&startDt=19640226&endDt=19640227&stnIds=108&dataCd=ASOS&dataType=JSON&serviceKey=" + API_KEY;										
				// * 주의 * https 아님 http 임. https 는 인증관련 복잡한 처리를 해야함.								
		RestTemplate restTemplate = new RestTemplate();										
												
		//// **** 중요 **** uri										
		URI uri = null; //java.net.URI 임포트 하셈										
		try {										
			uri = new URI(API_URL);									
		} catch (URISyntaxException e) {										
			e.printStackTrace();									
		}										
		
		String s = restTemplate.getForObject(uri, String.class); //										
		log.info("====== 우리나라 날씨 잘 나오나? "+s);
		
		
		KWeatherVo kw = restTemplate.getForObject(uri, KWeatherVo.class); // 자기 클래스로 바꾸시오..								
		log.info("==== json ==== : 우리나라 날씨 잘 나오냐? : "+kw.response.body.dataType);								
		String location = kw.response.body.items.item.get(0).stnNm;								
		String tMin = kw.response.body.items.item.get(0).minTa;								
		String tMax = kw.response.body.items.item.get(0).maxTa;								
		String ddara = String.format("==== json ==== : 어제의 날씨입니다~ 어제 %s 의 최저기온은 %s 도 최고 기온은 %s 였습니다. 날씨였습니다.", location, tMin, tMax);								
		log.info(ddara);	
		model.addAttribute("api",kw);
	}
	@GetMapping("/script")
	public void alert(Model model) {
			String a = String.format("alert('아이디를 입력해주세요!');");
			String b = String.format("alert('');");
		boolean aa= true; // << 필요할때 바꿀수 있어
		if(!aa) {
			model.addAttribute("ss",a);
		} else if(aa){
			model.addAttribute("ss",b);
		}
	}
	
}
