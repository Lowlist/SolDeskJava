package com.lowlist.dto.mapleapi;

import lombok.Data;

@Data
public class SqlCountData {
	public String character_name;
	public String table_name;
}
