package com.lowlist.dto.mapleapi;

import lombok.Data;

@Data
public class StatCalc {
	
	public String stat_name;
	public String stat_value;
}
