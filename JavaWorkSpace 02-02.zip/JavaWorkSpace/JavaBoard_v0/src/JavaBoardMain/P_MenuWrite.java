package JavaBoardMain;

import JavaBoradData.BoradFunsion;
import JavaBoradData.MenuWriteData;
import Util.Ci;
import Util.Cw;

public class P_MenuWrite {

	static void menuwriterun() {

		String title;
		while (true) {
			title = Ci.r("글제목");
			if (title.length() > 0) {
				BoradFunsion.titledata.add(new MenuWriteData(title));
				break;
			} else {
				Cw.wn("1개 이상의 문자를 입력해주세요!");
			}

			String content;
			while (true) {
				content = Ci.rl("글내용");
				if (content.length() > 0) {
					BoradFunsion.contentdata.add(new MenuWriteData(content));
					break;
				} else {
					Cw.wn("장난x");
				}
			}
			String writer;
			while (true) {
				writer = Ci.r("작성자");
				if (writer.length() > 0) {
					BoradFunsion.writerdata.add(new MenuWriteData(writer));
					break;
				} else {
					Cw.wn("장난x");
				}
			}
			
			

		}
	}

}
