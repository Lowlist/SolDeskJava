package Calc;

public class OnePan {

}
