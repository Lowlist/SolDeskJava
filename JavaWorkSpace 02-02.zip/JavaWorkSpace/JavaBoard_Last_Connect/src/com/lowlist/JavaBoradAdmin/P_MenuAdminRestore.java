package com.lowlist.JavaBoradAdmin;

import java.util.Scanner;

import com.lowlist.ApplyUtil.Cw;
import com.lowlist.JavaFunsionData.BoradFunsion;
import com.lowlist.JavaFunsionData.CalcHashMap;
import com.lowlist.MySqlConnectJavaBorad.MySqlConnect;
import com.lowlist.MySqlConnectJavaBorad.P_BoradClear;

public class P_MenuAdminRestore {

	public static void menurestorerun() {

		Scanner sc = new Scanner(System.in);
		if (!BoradFunsion.delCount.isEmpty()) {
			boolean restorechek = false;
			MySqlConnect.listrun("SELECT * FROM board WHERE b_delnumber = 1");
			Cw.wn("복구할 게시물 번호를 입력하세요:");
			String input = sc.nextLine();

			try {
				int del_restore = Integer.parseInt(input); // 문자열을 숫자로 변환

				if (del_restore > 0 && del_restore <= BoradFunsion.countdata.size()) {
					for (int i = 0; i < BoradFunsion.countdata.size(); i++) {
						if (BoradFunsion.BoradDataHash.get(del_restore - 1).del_number == 0) {
							if (!restorechek) {
								System.out.println("게시물이 존재하지 않습니다!");
								break;
							} else {
								System.out.println("복구완료!");
								break;
							}
						}
						if (BoradFunsion.BoradDataHash.get(i).del_number == 1) {

							String dbres = "UPDATE board SET b_delnumber = 0 WHERE b_no=" + del_restore;
							MySqlConnect.writerun(dbres);

							P_BoradClear.clearborad();
							MySqlConnect.javaaddrun();

							String resview = "SELECT *from board WHERE b_no=" + del_restore;
							MySqlConnect.viewrun(resview);
							System.out.println("복구완료!");
							restorechek = true;
							break;
						}
					}
				} else {
					System.out.println("유효한 게시물 번호가 아닙니다!");
				}

			} catch (NumberFormatException e) {
				System.out.println("유효한 입력이 아닙니다.");
			}
		} else {
			System.out.println("삭제된 게시물이 없습니다.");
		}
	}
}
//					예전코드
//					Product restore = BoradFunsion.delCount.get(del_restore - 1);
//					BoradFunsion.listdata.add(BoradFunsion.delCount.get(del_restore - 1));
//					BoradFunsion.countdata.add(BoradFunsion.delCount.get(del_restore - 1));

//					Cw.w("No." + del_restore + " ");
//					Cw.w("제목:" + restore.title + "/");
//					Cw.w("작성자:" + restore.write + "/");
//					Cw.wn("조회수:" + DataForBorad.view_limit);
//					Cw.wn("작성일:" + DataForBorad.date);
//					Cw.wn("〓〓〓〓〓〓〓〓〓〓〓〓〓");
//					Cw.wn("복구완료!");
//					BoradFunsion.delCount.remove(BoradFunsion.delCount.get(del_restore - 1));