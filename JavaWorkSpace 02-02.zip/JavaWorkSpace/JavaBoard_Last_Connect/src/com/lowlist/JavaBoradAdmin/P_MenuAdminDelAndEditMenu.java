package com.lowlist.JavaBoradAdmin;

import java.util.Scanner;

import com.lowlist.ApplyUtil.Cw;

public class P_MenuAdminDelAndEditMenu {

	public static void delandeditrun() {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		start:
		while(true) {
			Cw.wn("[1]글수정 [2]삭제메뉴 [b]이전메뉴");
			String cmd = sc.nextLine();
			switch(cmd) {
			case "1":
				P_MenuAdminEditPost.menueditpostrun();
				break;
			case "2":
				P_MenuAdminDel.menudelrun();
				break;
			case "b":
				break start;
			}
			
			
			
		}
		
	}
	
	
}
