package com.lowlist.JavaFunsionData;

import java.util.Map;

public class CalcHashMap {
	public static Product borad_hashdata;
	public static void calcrun() {
	for(Map.Entry<Integer,Product> borad_data : BoradFunsion.BoradDataHash.entrySet()) {
			Product cc = borad_data.getValue();
			borad_hashdata = cc;
		}
	}
	
}
