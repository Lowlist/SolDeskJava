package MainFunsion;

public class Product {

	
	int Hai_1 = 4;
	int Hai_2 = 4;
	int Hai_3 = 4;
	int Hai_4 = 4;
	int Hai_5 = 4;
	int Hai_6 = 4;
	int Hai_7 = 4;
	int Hai_8 = 4;
	int Hai_9 = 4;
	
	int Dong = 4;
	int Nam = 4;
	int Sue = 4;
	int Buk = 4;
	int Back = 4;
	int Bal = 4;
	int Jung = 4;
	
	String Sak;
	String Man;
	String Tong;
	String Jihai;
	
	Product(int a, int b ,int c ,int d, int e, int f ,int g , int h ,int i){
		a=Hai_1;
		b=Hai_2;
		c=Hai_3;
		d=Hai_4;
		e=Hai_5;
		f=Hai_6;
		g=Hai_7;
		h=Hai_8;
		i=Hai_9;
	}
	
	Product(int a, int b, int c ,int d, int e ,int f, int g){
		
		a=Dong;
		b=Nam;
		c=Sue;
		d=Buk;
		e=Back;
		f=Bal;
		g=Jung;
		
	}
		
	
}
