package CheckAndCash;

import MenuInfo.MainFunsion;
import MenuInfo.Product;
import Util.Cw;

public class LastCash {

	public static void Lastcashrun() {
		int drink_price = 0;
		int dessert_price = 0;
		int all_cash = 0;
		for(Product drink_cash : MainFunsion.drink_T) {
			drink_price = drink_price + drink_cash.price;
		}
		for(Product dessert_cash : MainFunsion.dessert_T) {
			dessert_price = dessert_price + dessert_cash.price; 
		}
		all_cash = drink_price + dessert_price;
		Cw.wn("계산하실 금액은["+all_cash+"]원 입니다.");
	}
	
}
