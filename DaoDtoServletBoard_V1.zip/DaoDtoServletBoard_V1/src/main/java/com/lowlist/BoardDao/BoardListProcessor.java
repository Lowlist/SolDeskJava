package com.lowlist.BoardDao;

public class BoardListProcessor {

}
