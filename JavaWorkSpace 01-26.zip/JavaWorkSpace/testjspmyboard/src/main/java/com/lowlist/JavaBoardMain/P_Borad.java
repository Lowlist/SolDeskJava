package com.lowlist.JavaBoardMain;

import com.lowlist.ApplyDisplay.Disp;

public class P_Borad {

	void boradrun(){
		
		Disp.title();
		P_MainMenu.mainmenurun();
		
	}
	
}
