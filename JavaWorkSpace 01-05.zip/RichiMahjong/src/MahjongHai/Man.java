package MahjongHai;

public class Man {
	
	
	
	
}
