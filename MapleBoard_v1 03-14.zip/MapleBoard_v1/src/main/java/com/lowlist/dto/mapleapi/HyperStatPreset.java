package com.lowlist.dto.mapleapi;

import lombok.Data;

@Data
public class HyperStatPreset {
	public String stat_type;
	public Integer stat_point;
	public Integer stat_level;
	public String stat_increase;
}
