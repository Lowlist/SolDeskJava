let divId;
let changeHover;
let starForceData;
let change;
let datas;

$(document).ready(
    function() {
    let item_info = $('.item_popup_main');
    let hoverring = $('.item');
    let starforceline = $('.star_force_line');
        hoverring.hover(function(){
                divId = $(this).attr('id');
                starForceData = $(this).data(divId);
                console.log(divId);
                console.log(starForceData);
                datas = $(this).data('num');
                console.log("확인"+datas);
                starforcerun();
                item_info.show();
                starforceline.show();
                // 대상을 지목하는 걸 (이벤트가 발생한 친구를) 찾아내는걸 찾아야한다.
                //이걸 바깥으로 빼놓는게 좋을듯? 아 변수를 바깥에다가 지정해놓고 여기서 지정을 시키면 될꺼같은데
            }, function(){
                item_info.hide();
                starforceline.hide();
        });
    });
    function starforcerun () {
    // ring_4_starforce 요소의 데이터 가져오기
    // let starforce = parseInt($("#ring_4_starforce").data("ring_4_starforce"));
    let starforce = parseInt(starForceData);
    console.log('인트데이터 맞음?'+starforce);
    let starimg = "https://cdn.dak.gg/maple/images/tooltip/item/ico-starforce-yellow.png";
    let starblackimg = "https://cdn.dak.gg/maple/images/tooltip/item/ico-starforce-default.png";
    let container = document.getElementById("starforce");
    container.innerHTML = '';
    // 별 이미지 추가
    for (let i = 1; i <= starforce; i++) {
        let image = document.createElement("img");
        image.src = starimg;
        image.alt = "별 이미지";
        image.className = "starforceimg";
        container.appendChild(image);
        if (i % 5 === 0) {
            container.appendChild(document.createTextNode(" "));
        }
    }

    // 부족한 별 이미지 추가
    if (starforce <= 25) {
        for (let i = starforce + 1; i <= 25; i++) {
            let image = document.createElement("img");
            image.src = starblackimg;
            image.alt = "별 이미지";
            image.className = "starforceimg";
            container.appendChild(image);
            if (i % 5 === 0) {
                container.appendChild(document.createTextNode(" "));
            }
        }
    }
};

// function(){

// };