package com.lowlist.JavaBoradAdmin;

import java.util.Scanner;

import com.lowlist.ApplyUtil.Cw;
import com.lowlist.JavaBoardReadWrite.P_MenuList;
import com.lowlist.JavaFunsionData.BoradFunsion;
import com.lowlist.JavaFunsionData.CalcHashMap;
import com.lowlist.MySqlConnectJavaBorad.MySqlConnect;
import com.lowlist.MySqlConnectJavaBorad.P_BoradClear;

public class P_MenuAdminDel {

	public static void menudelrun() {

		Scanner sc = new Scanner(System.in);
		Cw.wn("작성한 게시물을 삭제하는 곳입니다.");
		if (!BoradFunsion.listdata.isEmpty()) {
			P_MenuList.menulistrun("[번호입력]페이지넘기기 [삭제메뉴:x]");
			Cw.wn("삭제할 게시물 번호를 입력하세요");
			CalcHashMap.calcrun();
			String input = sc.nextLine();

			// gpt 님의 코드입니다.

			try {
				int del_numbers = Integer.parseInt(input); // 문자열을 숫자로 변환
				
					// 입력된 번호가 게시물 범위 내에 있는지 확인
					if (del_numbers > 0 && del_numbers <= BoradFunsion.countdata.size()) {
						
						// for index 문 돌린 후 전체 배열 사이즈만큼 index 증가
						for(int i = 0;i<BoradFunsion.countdata.size();i++) {
							
							// for index if문으로 해쉬맵 내에 있는 삭제번호가 0과 일치하는지 확인
							if(BoradFunsion.BoradDataHash.get(i).del_number==0) {
								
								//전송문
								String dbdel = "UPDATE board SET b_delnumber = 1 WHERE b_no="+del_numbers;
								MySqlConnect.writerun(dbdel);
								
								//db 전송 후 sts 내에 ArrayList,HashMap 초기화
								P_BoradClear.clearborad();
								
								//초기화 후 db에 저장된 배열 다시 불러오기
								MySqlConnect.javaaddrun();
								break;
								
								}
							//if문으로 선택한 게시물 키값 불러와서 삭제번호 1과 일치할 경우 표기
							//무슨 버그인지는 모르겠는데 -1 안하면 작동 이상하게됨 ㅡㅡ
							//재원이형 정보(해쉬맵도 0번부터 시작함 ㄴㅇㄱ
							if(BoradFunsion.BoradDataHash.get(del_numbers-1).del_number==1) {
								Cw.wn("게시물이 존재하지 않습니다!");
								break;
								}
							}
						}else{
						//두번째 if문 else 란 (입력한 번호가 게시물 범위 내에 있는지 확인)
						Cw.wn("게시글 넘버를 제대로 입력해주세요!");
					}
					//try catch 문으로 숫자열 이외의 값을 받을경우 출력
				}catch (NumberFormatException e) {
				Cw.wn("유효한 입력이 아닙니다.");
			}
		}else{
			//맨 처음 if문 else란 (저장된 글 확인)
			Cw.wn("저장된 글이 없습니다!");
		}

	}
}
