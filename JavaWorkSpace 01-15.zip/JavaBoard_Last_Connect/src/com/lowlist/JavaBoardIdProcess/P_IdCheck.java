package com.lowlist.JavaBoardIdProcess;

import java.util.Map;
import java.util.Scanner;

import com.lowlist.ApplyUtil.Cw;
import com.lowlist.JavaBoardMain.P_MainMenuAdmin;
import com.lowlist.JavaBoardMain.P_MainMenuId;
import com.lowlist.JavaFunsionData.BoradFunsion;
import com.lowlist.JavaFunsionData.Product;

public class P_IdCheck {

	public static final String adminlogin ="admin";
	public static String idwiter = "";
	public static String id_value;
	public static String pw_value;
	public static int Unique_number;
	public static Product unique_no_chek;
	public static void idcheckrun() {

		Scanner sc = new Scanner(System.in);
		boolean pwExists = false;
		boolean idExists = false;
		boolean adminExists = false;
		int unique_no = 0;
		Cw.wn("아이디를 입력해주세요!");
		String cmd_id = sc.nextLine();
		id_value = cmd_id;
		
		for(Map.Entry<Product,String> unique_no_chek : BoradFunsion.idPwUniqueNoHash.entrySet()) {
			if(id_value.equals(unique_no_chek.getKey().id)){
				
				idExists = true;
				unique_no = unique_no_chek.getKey().b_no;
				if(id_value.equals(adminlogin)) {
					adminExists = true;
				}
				Cw.wn("비밀번호를 입력해주세요!");
				String cmd_pw = sc.nextLine();
				pw_value = cmd_pw;
				
				if(pw_value.equals(unique_no_chek.getValue())) {
					pwExists = true;
					break;
				}
			}
		}
		
		if(idExists && pwExists) {
			idwiter = id_value;
			Unique_number = unique_no;
			if(adminExists) {
				Cw.wn("관리자 확인 완료! 관리자 메뉴로 이동합니다.");
				P_MainMenuAdmin.menuadminlistrun();
			} else {
			Cw.wn("로그인 완료! 회원전용 글쓰기로 이동합니다.");
			P_MainMenuId.menuidlistrun();
			}
		} else {
			Cw.wn("아이디 또는 비밀번호가 다릅니다! 메인화면으로 이동합니다");
		}

	}

}
//		
//		for(Map.Entry<String,String> idchek : BoradFunsion.idPwDataHash.entrySet()) {
//			if(id_value.equals(idchek.getKey())) {
//				
//				idExists = true;
//				Cw.wn("비밀번호를 입력해주세요!");
//				String cmd_pw = sc.nextLine();
//				pw_value = cmd_pw;
//				
//				if(pw_value.equals(idchek.getValue())) {
//					pwExists = true;
//					break;
//				}
//			}
//		}
//		
//		if(idExists && pwExists && adminExists) {
//			Cw.wn("관리자 확인 완료! 관리자 메뉴로 이동합니다.");
//			idwiter = id_value;
//			P_MainMenuAdmin.class();
//			P_MainMenuId.menuidlistrun();
//		}
