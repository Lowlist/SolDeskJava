package com.lowlist.JavaBoardMain;

import com.lowlist.ApplyDisplay.Disp;
import com.lowlist.ApplyUtil.Ci;
import com.lowlist.ApplyUtil.Cw;
import com.lowlist.JavaBoardReadWrite.P_MenuIdWrite;
import com.lowlist.JavaBoardReadWrite.P_MenuList;
import com.lowlist.JavaBoardReadWrite.P_MenuNonIdWrite;
import com.lowlist.JavaBoardReadWrite.P_MenuRead;
import com.lowlist.JavaBoradAdmin.P_MenuAdminDelAndEditMenu;
import com.lowlist.JavaBoradAdmin.P_MenuAdminRestore;
import com.lowlist.JavaFunsionData.BoradFunsion;

public class P_MainMenuAdmin {
	
	public static void menuadminlistrun() {
		
		startmenu:
			while(true) {
				Disp.menuMainAdmin();
				String cmd =Ci.r("입력");
				switch(cmd) {
				case "1":
					if(!BoradFunsion.listdata.isEmpty()) {
					P_MenuList.menulistrun("[번호입력]페이지넘기기 [읽기메뉴:x]:");
					P_MenuRead.menureadrun();
					}else {
						Cw.wn("저장된 글이 없습니다!");
					}
					break ;
					
				case "2":
					P_MenuIdWrite.menuidwriterun();
					break ;
					
				case "3":
					P_MenuNonIdWrite.menuwriterun();
					break ;
					
				case "4":
					if(!BoradFunsion.listdata.isEmpty()) {
						P_MenuAdminDelAndEditMenu.delandeditrun();
					}else {
						Cw.wn("저장된 글이 없습니다!");
					}
					break ;
				case "5":
					P_MenuAdminRestore.menurestorerun();
					break;
					
				case "e":
					Cw.wn("로그아웃합니다.");
					break startmenu;
					
				default:
					Cw.wn("정해진 명령문을 입력해주세요!");
					break;
					
			}
		}
	}
}
