package com.lowlist.JavaBoardReadWrite;

import com.lowlist.ApplyUtil.Ci;
import com.lowlist.ApplyUtil.Cw;
import com.lowlist.MySqlConnectJavaBorad.MySqlConnect;

public class P_MenuList {
	static public final int PER_PAGE = 5;
	static public void menulistrun(String xx) {
		int startIndex = 0;		// 현재 페이지의 첫 글 인덱스
		int currentPage = 1;	// 현재 페이지
		
		////	전체 페이지 수를 구하기	////
		int totalPage = 0;
		if(MySqlConnect.dbPostCount() % PER_PAGE > 0) {
			totalPage = MySqlConnect.dbPostCount() / PER_PAGE + 1;
		}else {
			totalPage = MySqlConnect.dbPostCount() / PER_PAGE;
		}
		
		Cw.wn("총 페이지 수:"+totalPage);
		try {
		String cmd;
		start:
		while(true) {
			cmd = Ci.r(xx);
			if(cmd.equals("x")) {
				break;
			}
			currentPage = Integer.parseInt(cmd);
			if(currentPage > totalPage || currentPage < 1) {
				Cw.wn("페이지 범위에 맞지 않는 값입니다!");
				continue start;
			}

			startIndex = (currentPage - 1) * PER_PAGE;	// 페이지의 첫 인덱스를 계산해서 저장하기
			String sql = "select * from board where b_delnumber=0 limit "+startIndex+","+PER_PAGE;
			MySqlConnect.dblistrun(sql);
		}
			}catch(NumberFormatException e) {
			System.out.println("유효한 입력이 아닙니다.");
			menulistrun(xx);
		}
			
		
	}
//	public static void menulistrun() {
//		
//		LocalDate now = LocalDate.now();
//		DataForBorad.date = now.toString();
//		int list_number = 0;
//		
//		for (int i = 0; i < BoradFunsion.countdata.size(); i++) {
//			Product list_all = BoradFunsion.listdata.get(i);
//			list_number = i + 1;
//			Cw.w("No." + list_number + " ");
//			Cw.w("제목:" + list_all.title + "/");
//			Cw.w("작성자:" + list_all.write + "/");
//			Cw.wn("조회수:" + DataForBorad.view_limit);
//			Cw.wn("작성일:" + DataForBorad.date);
//			Cw.wn("〓〓〓〓〓〓〓〓〓〓〓〓〓");
//			
//		}
//		
//	}
//	
//	public static void dellistrun() {
//		
//		int del_number = 0;
//		for (int i = 0; i < BoradFunsion.deldata.size(); i++) {
//			Product del_all = BoradFunsion.deldata.get(i);
//			del_number = i + 1;
//			Cw.w("No." + del_number + " ");
//			Cw.w("제목:" + del_all.title + "/");
//			Cw.w("작성자:" + del_all.write + "/");
//			Cw.wn("조회수:" + DataForBorad.view_limit);
//			Cw.wn("작성일:" + DataForBorad.date);
//			Cw.wn("〓〓〓〓〓〓〓〓〓〓〓〓〓");
//
//		}
//		
//	}
	
}