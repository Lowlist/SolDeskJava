package com.lowlist.JavaBoardReadWrite;

import com.lowlist.ApplyUtil.Ci;
import com.lowlist.ApplyUtil.Cw;
import com.lowlist.JavaFunsionData.BoradFunsion;
import com.lowlist.JavaFunsionData.Product;
import com.lowlist.MySqlConnectJavaBorad.MySqlConnect;

public class P_MenuNonIdWrite {

	public static void menuwriterun() {
		//제목
		String title ="";
			while (true) {
				title = Ci.rw("글제목");
				if (title.length() > 0) {
//					BoradFunsion.countdata.add(new Product(title));
					break;
				} else {
					Cw.wn("1개 이상의 문자를 입력해주세요!");
				}
			}
		//내용
		String content;
			while (true) {
				content = Ci.rw("글내용");
				if (content.length() > 0) {
					break;
				} else {
					Cw.wn("1개 이상의 문자를 입력해주세요!");
				}
			}
		//작성자
		String writer;
			while (true) {
				writer = Ci.rw("작성자");
				if (writer.length() > 0) {
					
					break;
				} else {
					Cw.wn("1개 이상의 문자를 입력해주세요!");
				}
			}
		String pw_post;
			while (true) {
				pw_post = Ci.rw("게시물비밀번호");
				if (writer.length() > 0) {
					break;
				} else {
					Cw.wn("1개 이상의 문자를 입력해주세요!");
				}
			}
			
			Product list_all = new Product(title,content,writer,pw_post);
			BoradFunsion.listdata.add(list_all);
			
			Cw.wn("작성완료");
			
			String dbwriter = String.format(
					"insert into board (b_title,b_id,b_datetime,b_text,b_hit,b_postpw) "
					+ "values ('%s','%s',now(),'%s',0,'%s');"
					,title,writer,content,pw_post) ;
			
			MySqlConnect.writerun(dbwriter);
			
			}
		}

