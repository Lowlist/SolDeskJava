package com.lowlist.JavaFunsionData;

public class Product {

	public String text = "";
	public String title = "";
	public String content = "";
	public String write = "";
	public String post_pw = "";
	public int del_number = 0;
	public String id = "";
	public String pw = "";
	public int b_no = 0;
	
	public int removed = 0;
	
	// 0
	
	public Product (String aa) {
		this.text = aa;
	}
	
	
	public Product (String aa ,String bb){
		this.id = aa;
		this.pw = bb;
	}
	
	public Product (String aa,int cc){
		this.id = aa;
		this.b_no = cc;
	}
	
	public Product(String aa ,String bb, String cc,String dd) {
		title = aa;
		content = bb;
		write = cc;
		post_pw = dd;
	}
	public Product(int ab ,String aa ,String bb, String cc ,int dd,String ee) {
		b_no = ab;
		title = aa;
		content = bb;
		write = cc;
		del_number = dd;
		post_pw = ee;
	}

	
}
