package com.lowlist.JavaFunsionData;

import java.util.Map;

public class CalcHashMap {
	public static Product del_numbercalc;
	public static void calcrun() {
	for(Map.Entry<Integer,Product> borad_data : BoradFunsion.BoradDataHash.entrySet()) {
			Product cc = borad_data.getValue();
			del_numbercalc = cc;
		}
	}
	
}
