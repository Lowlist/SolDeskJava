CREATE DATABASE my_dog default CHARACTER SET UTF8MB4;
use my_dog;
use my_cat;
select * from dog_board;
select * from dog_board where b_del_number=0 limit 5,10;

create table dog_board(
	b_no int primary key auto_increment,			#글번호
    b_title char(100),								#제목
    b_content text,									#내용
    b_id char(30),									#작성자ID
    b_del_number int not null default 0 ,			#삭제여부
    b_hit int not null default 0,					#조회수
    b_datetime datetime not null default now(),		#작성시간
    b_comment_count int not null default 0,			#댓글수
    b_commnet_ori int not null default -1			#댓글의 원글 번호
);

insert into PS_BOARD_FREE values(0,'테스트제목','테스트내용 내용.......',now(),0,'dddd',0,0);
insert into dog_board values(0,'테스트제목2','테스트내용2 내용.......2','dog3',0);

CREATE TABLE PS_BOARD_FREE (
		B_NO INT PRIMARY KEY AUTO_INCREMENT, 			#글번호
		B_TITLE CHAR(100) NOT NULL DEFAULT "",			#글제목
	    B_ID CHAR(50) NOT NULL,							#작성자ID
		B_DATETIME DATETIME NOT NULL DEFAULT now(),		#작성시간
	    B_HIT INT NOT NULL DEFAULT 0,					#조회수    
	    B_TEXT TEXT	NOT NULL,							#글내용, 댓글내용
	    B_REPLY_COUNT INT NOT NULL DEFAULT 0,			#댓글수
	    B_REPLY_ORI INT	NOT NULL DEFAULT -1				#댓글의 원글 번호
	);

drop table ps_board_free;

select*from PS_BOARD_FREE;

insert into ps_board_free (b_title,b_id,b_text) values ('야옹','cat','aaa');

drop table dog_board;