package q16JavaMemory;

public class Cat {

	String name = "";
	int age = 0;
	String type = "";
	
	
}
