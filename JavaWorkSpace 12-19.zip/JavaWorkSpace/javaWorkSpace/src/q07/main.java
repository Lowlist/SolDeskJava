package q07;

import q07.lotto;

public class main {
	
	public static void main(String[] args) {
		lotto r = new lotto();
		r.run();
	}
}
