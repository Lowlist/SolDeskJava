package q23_v9_kiosk;

public class Cash extends MenuInfo {

	
	void x() {
		
		drink.add(dr1);
		drink.add(dr2);
		drink.add(dr3);
		
		drinksize.add(si1);
		drinksize.add(si2);
		drinksize.add(si3);
		
		newnewnew.add(drink.get(0));
		newnewnew.add(drink.get(1));
		newnewnew.add(drinksize.get(0));
	
	}
	
	
}
