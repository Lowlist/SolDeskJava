package JavaBoardMain;

import Util.Cw;

public class P_MenuWrite {

	static void menuwriterun() {
		Cw.wn("글쓰기");
	}
	
}
