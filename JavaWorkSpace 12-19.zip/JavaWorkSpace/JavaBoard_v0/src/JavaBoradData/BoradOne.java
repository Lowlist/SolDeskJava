package JavaBoradData;

public class BoradOne {

}
