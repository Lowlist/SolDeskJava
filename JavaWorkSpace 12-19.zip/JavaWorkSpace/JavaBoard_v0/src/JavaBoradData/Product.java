package JavaBoradData;

public class Product {

}
