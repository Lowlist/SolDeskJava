package JavaBoradData;

public class DataForBorad {
	public static final String VERSION = "v0.0.1";
	public static final String TITLE = "솔패밀리 게시판 (" + VERSION + ") feat.Jo";
}
